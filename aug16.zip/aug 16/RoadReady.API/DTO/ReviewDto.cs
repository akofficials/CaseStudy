﻿namespace RoadReady.API.DTO
{
    public class ReviewDto
    {
        public int UserId { get; set; }
        public int VehicleId { get; set; }
        public int Rating { get; set; }
        public string Comment { get; set; }
    }
}
