﻿using RoadReady.API.DTO;
using RoadReady.API.Interfaces;
using RoadReady.API.Models;

namespace RoadReady.API.Services
{
    public class ReservationService : IReservationService
    {
        private readonly IReservationRepository _repo;
        private readonly IVehicleRepository _vehicleRepo;

        public ReservationService(IReservationRepository repo, IVehicleRepository vehicleRepo)
        {
            _repo = repo;
            _vehicleRepo = vehicleRepo;
        }

        // Get all reservations for a specific user
        public async Task<IEnumerable<ReservationDto>> GetUserReservationsAsync(int userId)
        {
            var reservations = await _repo.GetByUserIdAsync(userId);

            return reservations.Select(r => new ReservationDto
            {
                ReservationId = r.ReservationId,
                VehicleId = r.VehicleId,
                VehicleModel = r.Vehicle?.Model ?? "Unknown",
                PickupDate = r.PickupDate,
                DropOffDate = r.DropOffDate,
                TotalPrice = r.TotalPrice,
                IsCancelled = r.IsCancelled
            });
        }

        // NEW: Get all reservations (for admin dashboard)
        public async Task<IEnumerable<ReservationDto>> GetAllReservationsAsync()
        {
            var reservations = await _repo.GetAllAsync();

            return reservations.Select(r => new ReservationDto
            {
                ReservationId = r.ReservationId,
                VehicleId = r.VehicleId,
                VehicleModel = r.Vehicle?.Model ?? "Unknown",
                PickupDate = r.PickupDate,
                DropOffDate = r.DropOffDate,
                TotalPrice = r.TotalPrice,
                IsCancelled = r.IsCancelled
            });
        }

        // Create reservation from full DTO
        public async Task CreateReservationAsync(ReservationDto dto)
        {
            var vehicle = await _vehicleRepo.GetByIdAsync(dto.VehicleId);
            if (vehicle == null || !vehicle.IsAvailable)
                throw new Exception("Vehicle not available.");

            var overlapping = vehicle.Reservations?.Any(r =>
                !r.IsCancelled &&
                r.PickupDate < dto.DropOffDate &&
                r.DropOffDate > dto.PickupDate) ?? false;

            if (overlapping)
                throw new Exception("Vehicle is already booked for selected dates.");

            var totalDays = (dto.DropOffDate - dto.PickupDate).Days;
            if (totalDays <= 0)
                throw new Exception("Invalid date range.");

            var reservation = new Reservation
            {
                UserId = dto.UserId,
                VehicleId = dto.VehicleId,
                PickupDate = dto.PickupDate,
                DropOffDate = dto.DropOffDate,
                TotalPrice = vehicle.PricePerDay * totalDays,
                IsCancelled = false
            };

            await _repo.AddAsync(reservation);
            await _repo.SaveChangesAsync();
        }

        // Create reservation from CreateReservationDto and userId
        public async Task AddReservationAsync(int userId, CreateReservationDto dto)
        {
            var vehicle = await _vehicleRepo.GetByIdAsync(dto.VehicleId);
            if (vehicle == null || !vehicle.IsAvailable)
                throw new Exception("Vehicle not available.");

            var overlapping = vehicle.Reservations?.Any(r =>
                !r.IsCancelled &&
                r.PickupDate < dto.DropOffDate &&
                r.DropOffDate > dto.PickupDate) ?? false;

            if (overlapping)
                throw new Exception("Vehicle is already booked for selected dates.");

            var totalDays = (dto.DropOffDate - dto.PickupDate).Days;
            if (totalDays <= 0)
                throw new Exception("Invalid date range.");

            var reservation = new Reservation
            {
                UserId = userId,
                VehicleId = dto.VehicleId,
                PickupDate = dto.PickupDate,
                DropOffDate = dto.DropOffDate,
                TotalPrice = vehicle.PricePerDay * totalDays,
                IsCancelled = false
            };

            await _repo.AddAsync(reservation);
            await _repo.SaveChangesAsync();
        }

        // Cancel a reservation for a specific user
        public async Task<bool> CancelReservationAsync(int userId, int reservationId)
        {
            var reservation = await _repo.GetByIdAsync(reservationId);
            if (reservation == null || reservation.UserId != userId)
                return false;

            reservation.IsCancelled = true;
            return await _repo.SaveChangesAsync();
        }
    }
}
