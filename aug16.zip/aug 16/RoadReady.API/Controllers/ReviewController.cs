﻿using Microsoft.AspNetCore.Mvc;
using RoadReady.API.DTO;
using RoadReady.API.Interfaces;

namespace RoadReady.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReviewController : ControllerBase
    {
        private readonly IReviewService _service;

        public ReviewController(IReviewService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> AddReview(ReviewDto dto)
        {
            await _service.AddReviewAsync(dto);
            return Ok(new { message = "Review added successfully" });
        }

        [HttpGet("{vehicleId}")]
        public async Task<IActionResult> GetReviews(int vehicleId)
        {
            var reviews = await _service.GetReviewsByVehicleAsync(vehicleId);
            return Ok(reviews);
        }
    }
}
