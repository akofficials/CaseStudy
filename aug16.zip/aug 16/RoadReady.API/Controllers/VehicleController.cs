﻿using Microsoft.AspNetCore.Mvc;
using RoadReady.API.DTO;
using RoadReady.API.Interfaces;

namespace RoadReady.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VehicleController : ControllerBase
    {
        private readonly IVehicleService _service;

        public VehicleController(IVehicleService service)
        {
            _service = service;
        }

        // GET all vehicles
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var vehicles = await _service.GetAllVehiclesAsync();
            return Ok(vehicles);
        }

        // GET single vehicle
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var vehicle = await _service.GetVehicleByIdAsync(id);
            if (vehicle == null) return NotFound();
            return Ok(vehicle);
        }

        // POST new vehicle
        [HttpPost]
        public async Task<IActionResult> Add(VehicleDto dto)
        {
            await _service.AddVehicleAsync(dto);
            return Ok(new { message = "Vehicle added successfully" });
        }

        // PUT update vehicle (edit)
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, VehicleDto dto)
        {
            var existingVehicle = await _service.GetVehicleByIdAsync(id);
            if (existingVehicle == null) return NotFound();

            await _service.UpdateVehicleAsync(id, dto);
            return Ok(new { message = "Vehicle updated successfully" });
        }

        // PATCH toggle availability
        [HttpPatch("{id}/availability")]
        public async Task<IActionResult> UpdateAvailability(int id, [FromBody] bool available)
        {
            var existingVehicle = await _service.GetVehicleByIdAsync(id);
            if (existingVehicle == null) return NotFound();

            await _service.UpdateAvailabilityAsync(id, available);
            return Ok(new { message = "Availability updated successfully" });
        }

        // DELETE vehicle
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var existingVehicle = await _service.GetVehicleByIdAsync(id);
            if (existingVehicle == null) return NotFound();

            await _service.DeleteVehicleAsync(id);
            return Ok(new { message = "Vehicle deleted successfully" });
        }

        // Search available vehicles
        [HttpGet("search")]
        public async Task<IActionResult> Search(
            [FromQuery] string model,
            [FromQuery] string location,
            [FromQuery] DateTime pickup,
            [FromQuery] DateTime dropoff)
        {
            if (pickup >= dropoff)
            {
                return BadRequest("Drop-off date must be after pickup date.");
            }

            var oneMonthLater = pickup.AddMonths(1);
            if (dropoff > oneMonthLater)
            {
                return BadRequest("Drop-off date must be within one month of pickup date.");
            }

            var vehicles = await _service.SearchAvailableVehiclesAsync(model, location, pickup, dropoff);
            return Ok(vehicles);
        }
    }
}
