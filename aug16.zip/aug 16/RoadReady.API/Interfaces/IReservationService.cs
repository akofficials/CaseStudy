﻿using RoadReady.API.DTO;

namespace RoadReady.API.Interfaces
{
    public interface IReservationService
    {
        Task<IEnumerable<ReservationDto>> GetUserReservationsAsync(int userId);
        Task<IEnumerable<ReservationDto>> GetAllReservationsAsync(); // NEW
        Task CreateReservationAsync(ReservationDto dto);
        Task AddReservationAsync(int userId, CreateReservationDto dto);
        Task<bool> CancelReservationAsync(int userId, int reservationId);
    }
}
