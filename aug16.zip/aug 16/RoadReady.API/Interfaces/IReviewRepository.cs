﻿using RoadReady.API.Models;

namespace RoadReady.API.Interfaces
{
    public interface IReviewRepository
    {
        Task AddAsync(Review review);
        Task<IEnumerable<Review>> GetByVehicleIdAsync(int vehicleId);
        Task<bool> SaveChangesAsync();
    }
}
