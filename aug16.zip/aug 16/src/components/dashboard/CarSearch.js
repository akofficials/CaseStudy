import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // ✅ import navigate hook
import "./carsearch.css";

const CarSearch = () => {
  const [model, setModel] = useState("");
  const [pickupLocation, setPickupLocation] = useState("");
  const [pickupDate, setPickupDate] = useState("");
  const [dropoffDate, setDropoffDate] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate(); // ✅ initialize navigate

  const carImages = {
    Camry: "src/components/dashboard/camry.jpeg",
    Civic:
      "https://automobiles.honda.com/-/media/Honda-Automobiles/Vehicles/2024/civic-sedan/Global-Assets/MY24-Civic-Sedan-Touring-Blue.jpg",
    Fusion:
      "https://www.ford.com/cmslibs/content/dam/brand_ford/en_us/brand/cars/fusion/2020/collections/3-2/20_fusion_34front.jpg",
    Elantra:
      "https://www.hyundai.com/content/dam/hyundai/ww/en/images/find-a-car/pip/cars/elantra/2024/pc/elantra-highlights-kv-pc.jpg",
    Malibu:
      "https://www.chevrolet.com/content/dam/chevrolet/na/us/english/index/vehicles/2024/cars/malibu/mov/01-images/mov-2024-malibu-ext-gallery-01.jpg",
  };

  const handleSearch = async () => {
    if (!model || !pickupLocation || !pickupDate || !dropoffDate) {
      alert(
        "Please select model, pickup location, pickup date, and drop-off date."
      );
      return;
    }

    const pickup = new Date(pickupDate);
    const dropoff = new Date(dropoffDate);
    const oneMonthLater = new Date(pickup);
    oneMonthLater.setMonth(oneMonthLater.getMonth() + 1);

    if (pickup >= dropoff) {
      alert("Drop-off date must be after pickup date.");
      return;
    }

    if (dropoff > oneMonthLater) {
      alert("Drop-off date must be within one month of pickup date.");
      return;
    }

    const url = `https://localhost:7294/api/Vehicle/search?model=${encodeURIComponent(
      model
    )}&location=${encodeURIComponent(pickupLocation)}&pickup=${
      pickup.toISOString().split("T")[0]
    }&dropoff=${dropoff.toISOString().split("T")[0]}`;

    try {
      setLoading(true);
      const response = await fetch(url);
      if (!response.ok) {
        const error = await response.text();
        alert("Search failed: " + error);
        return;
      }
      const data = await response.json();
      setResults(data);
      if (data.length === 0) {
        alert("No vehicles available for your selection.");
      }
    } catch (err) {
      console.error("Search error:", err);
      alert("Error while searching for cars.");
    } finally {
      setLoading(false);
    }
  };

  const handleReserve = (car) => {
    // Save booking info in localStorage
    localStorage.setItem("selectedCar", JSON.stringify(car));
    localStorage.setItem("pickupDate", pickupDate);
    localStorage.setItem("dropoffDate", dropoffDate);

    // Show booking successful alert
    alert("Booking Successful!");

    // Redirect to review page
    navigate(`/review/${car.vehicleId}`);
  };

  return (
    <div className="car-search-container">
      <h2>Find Available Cars</h2>
      <div className="search-form">
        <select value={model} onChange={(e) => setModel(e.target.value)}>
          <option value="">Select Model</option>
          <option value="Camry">Camry</option>
          <option value="Civic">Civic</option>
          <option value="Fusion">Fusion</option>
          <option value="Elantra">Elantra</option>
          <option value="Malibu">Malibu</option>
        </select>

        <select
          value={pickupLocation}
          onChange={(e) => setPickupLocation(e.target.value)}
        >
          <option value="">Pickup Location</option>
          <option value="Chennai">Chennai</option>
          <option value="Coimbatore">Coimbatore</option>
          <option value="Tiruchirappalli">Tiruchirappalli</option>
          <option value="Madurai">Madurai</option>
          <option value="Kanniyakumari">Kanniyakumari</option>
          <option value="Vellore">Vellore</option>
          <option value="Salem">Salem</option>
        </select>

        <input
          type="date"
          value={pickupDate}
          onChange={(e) => setPickupDate(e.target.value)}
        />

        <input
          type="date"
          value={dropoffDate}
          onChange={(e) => setDropoffDate(e.target.value)}
        />

        <button onClick={handleSearch} disabled={loading}>
          {loading ? "Searching..." : "Search"}
        </button>
      </div>

      <div className="car-results">
        {results.map((car) => (
          <div key={car.vehicleId} className="car-card">
            <img
              src={
                car.imageUrl ||
                carImages[car.model] ||
                "src/components/dashboard/camry.jpeg"
              }
              alt={car.model}
            />
            <h3>
              {car.make} {car.model}
            </h3>
            <p>
              {car.year} | {car.location}
            </p>
            <p>₹{car.pricePerDay} / day</p>
            <button onClick={() => handleReserve(car)}>Reserve</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CarSearch;
