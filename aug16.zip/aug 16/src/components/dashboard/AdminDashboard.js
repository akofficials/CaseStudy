import React, { useState, useEffect } from "react";
import "./dashboard.css";
import { useNavigate } from "react-router-dom";
import ManageUsers from "./ManageUsers";
import ManageCars from "./ManageCars";
import Bookings from "./Bookings";

const Reservations = () => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchReservations = async () => {
      try {
        const response = await fetch("https://localhost:7294/api/Reservation");
        if (!response.ok) {
          throw new Error("Failed to fetch reservations");
        }
        const data = await response.json();
        setReservations(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchReservations();
  }, []);

  if (loading) return <p>Loading reservations...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (
    <div>
      <h2>All Reservations</h2>
      {reservations.length === 0 ? (
        <p>No reservations found.</p>
      ) : (
        <table className="reservation-table">
          <thead>
            <tr>
              <th>Vehicle</th>
              <th>User</th>
              <th>Pickup Date</th>
              <th>Drop-off Date</th>
            </tr>
          </thead>
          <tbody>
            {reservations.map((res) => (
              <tr key={res.reservationId}>
                <td>
                  {res.vehicle?.make} {res.vehicle?.model}
                </td>
                <td>{res.user?.name || "N/A"}</td>
                <td>{new Date(res.pickupDate).toLocaleDateString()}</td>
                <td>{new Date(res.dropoffDate).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

const Feedback = () => <p>Manage user feedback.</p>;

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("users");
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/");
  };

  const renderContent = () => {
    switch (activeTab) {
      case "users":
        return <ManageUsers />;
      case "cars":
        return <ManageCars />;
      case "reservations":
        return <Bookings />;
      case "feedback":
        return <Feedback />;
      default:
        return null;
    }
  };

  return (
    <div className="dashboard-container">
      <div className="sidebar">
        <div>
          <h2>Admin Panel</h2>
          <div className="nav-buttons">
            <button
              className="nav-button"
              onClick={() => setActiveTab("users")}
            >
              Manage Users
            </button>
            <button className="nav-button" onClick={() => setActiveTab("cars")}>
              Vehicle Record
            </button>
            <button
              className="nav-button"
              onClick={() => setActiveTab("reservations")}
            >
              Reservations
            </button>
            <button
              className="nav-button"
              onClick={() => setActiveTab("feedback")}
            >
              User Feedback
            </button>
          </div>
        </div>
        <button className="nav-button" onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div className="content">
        <h1>{activeTab.toUpperCase().replace(/_/g, " ")}</h1>
        {renderContent()}
      </div>
    </div>
  );
};

export default AdminDashboard;
