import React, { useState, useEffect } from "react";
import "./ManageCars.css";

const API_URL = "https://localhost:7294/api/Vehicle";

const ManageCars = () => {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [showForm, setShowForm] = useState(false);
  const [editingCarId, setEditingCarId] = useState(null);
  const [newCar, setNewCar] = useState({
    make: "",
    model: "",
    year: "",
    available: true,
  });

  // Fetch cars from API
  const fetchCars = () => {
    setLoading(true);
    fetch(API_URL)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch cars");
        return res.json();
      })
      .then((data) => {
        setCars(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchCars();
  }, []);

  // Toggle Availability (PATCH/PUT request)
  const toggleAvailability = (id, currentStatus) => {
    fetch(`${"https://localhost:7294/api/Vehicle"}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ available: !currentStatus }),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to update availability");
        fetchCars();
      })
      .catch((err) => alert(err.message));
  };

  // Delete car (DELETE request)
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this car?")) {
      fetch(`${"https://localhost:7294/api/Vehicle"}/${id}`, {
        method: "DELETE",
      })
        .then((res) => {
          if (!res.ok) throw new Error("Failed to delete car");
          setCars((prev) => prev.filter((car) => car.id !== id));
        })
        .catch((err) => alert(err.message));
    }
  };

  // Edit car — populate form with existing data
  const handleEdit = (car) => {
    setEditingCarId(car.id);
    setNewCar({
      make: car.make,
      model: car.model,
      year: car.year,
      available: car.available,
    });
    setShowForm(true);
  };

  const handleAddCarClick = () => {
    setEditingCarId(null);
    setNewCar({ make: "", model: "", year: "", available: true });
    setShowForm(true);
  };

  const handleFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNewCar((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? checked : name === "year" ? Number(value) : value,
    }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const method = editingCarId ? "PUT" : "POST";
    const url = editingCarId ? `${API_URL}/${editingCarId}` : API_URL;

    fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newCar),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to save car");
        return res.json();
      })
      .then(() => {
        fetchCars();
        setNewCar({ make: "", model: "", year: "", available: true });
        setShowForm(false);
        setEditingCarId(null);
      })
      .catch((err) => alert(err.message));
  };

  if (loading) return <p>Loading cars...</p>;
  if (error) return <p style={{ color: "red" }}>Error: {error}</p>;

  return (
    <div className="manage-cars-container">
      <h2>Manage Cars</h2>
      <button className="add-car-button" onClick={handleAddCarClick}>
        Add New Car
      </button>

      {showForm && (
        <form className="add-car-form" onSubmit={handleFormSubmit}>
          <input
            type="text"
            name="make"
            placeholder="Make"
            value={newCar.make}
            onChange={handleFormChange}
          />
          <input
            type="text"
            name="model"
            placeholder="Model"
            value={newCar.model}
            onChange={handleFormChange}
          />
          <input
            type="number"
            name="year"
            placeholder="Year"
            value={newCar.year}
            onChange={handleFormChange}
          />
          <label>
            <input
              type="checkbox"
              name="available"
              checked={newCar.available}
              onChange={handleFormChange}
            />{" "}
            Available
          </label>
          <button type="submit">
            {editingCarId ? "Update Car" : "Save Car"}
          </button>
        </form>
      )}

      <table className="car-table">
        <thead>
          <tr>
            <th>Make</th>
            <th>Model</th>
            <th>Year</th>
            <th>Availability</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {cars.map((car) => (
            <tr key={car.id}>
              <td>{car.make}</td>
              <td>{car.model}</td>
              <td>{car.year}</td>
              <td>
                <span
                  className={
                    car.available ? "status-active" : "status-inactive"
                  }
                >
                  {car.available ? "Available" : "Unavailable"}
                </span>
              </td>
              <td>
                <div className="action-buttons">
                  <button
                    className="action-button edit-button"
                    onClick={() => handleEdit(car)}
                  >
                    Edit
                  </button>
                  <button
                    className="action-button delete-button"
                    onClick={() => handleDelete(car.id)}
                  >
                    Delete
                  </button>
                  <button
                    className="action-button toggle-button"
                    onClick={() => toggleAvailability(car.id, car.available)}
                  >
                    {car.available ? "Deactivate" : "Activate"}
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ManageCars;
