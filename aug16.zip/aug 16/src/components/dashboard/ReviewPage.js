import React, { useState } from "react";
import { useParams } from "react-router-dom";

import "./reviewpage.css";

const ReviewPage = () => {
  const { vehicleId } = useParams();
  const [review, setReview] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Review Submitted:", review);
    setReview("");
  };

  return (
    <div className="review-page-container">
      <h2>Write a Review for Vehicle {vehicleId}</h2>
      <form onSubmit={handleSubmit} className="review-form">
        <textarea
          className="review-textarea"
          placeholder="Write your review here..."
          value={review}
          onChange={(e) => setReview(e.target.value)}
        />
        <button type="submit" className="submit-btn">
          Submit Review
        </button>
      </form>
    </div>
  );
};

export default ReviewPage;
