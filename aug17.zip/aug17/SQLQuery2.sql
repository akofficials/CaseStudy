select * from Users

INSERT INTO Vehicles (Make, Model, Year, ImageUrl, PricePerDay, Location, IsAvailable)
VALUES
('Toyota', 'Camry', 2023, 'https://imgd.aeplcdn.com/1280x720/n/cw/ec/109815/toyota-camry-exterior-right-front-three-quarter.jpeg', 2500, 'Chennai', 1),

('Honda', 'Civic', 2022, 'https://hips.hearstapps.com/hmg-prod/images/2022-honda-civic-sport-131-1630342521.jpg', 2200, 'Coimbatore', 1),

('Ford', 'Fusion', 2021, 'https://st.motortrend.com/uploads/sites/10/2019/09/2020-ford-fusion-se-sedan-angular-front.png', 2000, 'Madurai', 1);


INSERT INTO Reservations (UserId, VehicleId, PickupDate, DropOffDate, TotalPrice, IsCancelled)
VALUES (1, 1, '2025-08-20', '2025-08-25', 12500, 0);

DELETE FROM Reservations;


INSERT INTO Reservations (UserId, VehicleId, PickupDate, DropOffDate, TotalPrice, IsCancelled)
VALUES (1, 2, '2025-08-20', '2025-08-25', 10000, 0);

SELECT * FROM Reservations

DBCC CHECKIDENT ('Reservations', RESEED, 0);

select * from Vehicles

