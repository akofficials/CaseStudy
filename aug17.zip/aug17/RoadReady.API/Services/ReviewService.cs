﻿using RoadReady.API.DTO;
using RoadReady.API.Interfaces;
using RoadReady.API.Models;

namespace RoadReady.API.Services
{
    public class ReviewService : IReviewService
    {
        private readonly IReviewRepository _repo;

        public ReviewService(IReviewRepository repo)
        {
            _repo = repo;
        }

        public async Task AddReviewAsync(ReviewDto dto)
        {
            var review = new Review
            {
                UserId = dto.UserId,
                VehicleId = dto.VehicleId,
                Rating = dto.Rating,
                Comment = dto.Comment
            };
            await _repo.AddAsync(review);
            await _repo.SaveChangesAsync();
        }

        public async Task<IEnumerable<ReviewDto>> GetReviewsByVehicleAsync(int vehicleId)
        {
            var reviews = await _repo.GetByVehicleIdAsync(vehicleId);
            return reviews.Select(r => new ReviewDto
            {
                UserId = r.UserId,
                VehicleId = r.VehicleId,
                Rating = r.Rating,
                Comment = r.Comment
            });
        }
    }
}
