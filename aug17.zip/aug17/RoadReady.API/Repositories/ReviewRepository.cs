﻿using Microsoft.EntityFrameworkCore;
using RoadReady.API.Data;
using RoadReady.API.Models;
using RoadReady.API.Interfaces;

namespace RoadReady.API.Repositories
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly RoadReadyDbContext _context;

        public ReviewRepository(RoadReadyDbContext context)
        {
            _context = context;
        }

        public async Task AddAsync(Review review)
        {
            await _context.Reviews.AddAsync(review);
        }

        public async Task<IEnumerable<Review>> GetByVehicleIdAsync(int vehicleId)
        {
            return await _context.Reviews
                .Where(r => r.VehicleId == vehicleId)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
