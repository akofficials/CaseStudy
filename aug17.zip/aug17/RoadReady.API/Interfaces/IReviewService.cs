﻿using RoadReady.API.DTO;

namespace RoadReady.API.Interfaces
{
    public interface IReviewService
    {
        Task AddReviewAsync(ReviewDto dto);
        Task<IEnumerable<ReviewDto>> GetReviewsByVehicleAsync(int vehicleId);
    }
}
