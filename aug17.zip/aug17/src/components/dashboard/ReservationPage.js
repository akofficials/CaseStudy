import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const ReservationPage = () => {
  const [reservedCar, setReservedCar] = useState(null);
  const [pickupDate, setPickupDate] = useState("");
  const [dropoffDate, setDropoffDate] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const car = JSON.parse(localStorage.getItem("selectedCar"));
    const pickup = localStorage.getItem("pickupDate");
    const dropoff = localStorage.getItem("dropoffDate");

    setReservedCar(car);
    setPickupDate(pickup);
    setDropoffDate(dropoff);
  }, []);

  if (!reservedCar) {
    return <h2>No reservation found!</h2>;
  }

  const handleReview = () => {
    navigate(`/review/${reservedCar.vehicleId}`);
  };

  return (
    <div style={{ maxWidth: "600px", margin: "0 auto", padding: "20px" }}>
      <h2>Reservation Confirmed ✅</h2>
      <div
        style={{
          border: "1px solid #ccc",
          borderRadius: "10px",
          padding: "15px",
          marginTop: "20px",
          textAlign: "center",
        }}
      >
        <h3>
          {reservedCar.make} {reservedCar.model}
        </h3>
        <p>
          Year: {reservedCar.year} | Location: {reservedCar.location}
        </p>
        <p>₹{reservedCar.pricePerDay} / day</p>
        <p>
          Pickup: {pickupDate} <br /> Drop-off: {dropoffDate}
        </p>

        {/* ✅ Review Button */}
        <button
          onClick={handleReview}
          style={{
            marginTop: "15px",
            padding: "10px 20px",
            borderRadius: "5px",
            border: "none",
            backgroundColor: "#007bff",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          Write a Review
        </button>
      </div>
    </div>
  );
};

export default ReservationPage;
