import React, { useState, useEffect } from "react";
import "./ManageCars.css";

const API_URL = "https://localhost:7294/api/Vehicle";

const ManageCars = () => {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [showForm, setShowForm] = useState(false);
  const [editingCarId, setEditingCarId] = useState(null);

  const [newCar, setNewCar] = useState({
    make: "",
    model: "",
    year: "",
    pricePerDay: "",
    location: "",
    imageUrl: "",
    isAvailable: true,
  });

  // ✅ Fetch cars from API
  const fetchCars = () => {
    setLoading(true);
    fetch(API_URL)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch cars");
        return res.json();
      })
      .then((data) => {
        setCars(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchCars();
  }, []);

  // ✅ Delete car
  const handleDelete = (vehicleId) => {
    if (window.confirm("Are you sure you want to delete this car?")) {
      fetch(`${API_URL}/${vehicleId}`, { method: "DELETE" })
        .then((res) => {
          if (!res.ok) throw new Error("Failed to delete car");
          setCars((prev) => prev.filter((car) => car.vehicleId !== vehicleId));
        })
        .catch((err) => alert(err.message));
    }
  };

  // ✅ Edit car
  const handleEdit = (car) => {
    setEditingCarId(car.vehicleId);
    setNewCar({
      make: car.make,
      model: car.model,
      year: car.year,
      pricePerDay: car.pricePerDay,
      location: car.location,
      imageUrl: car.imageUrl,
      isAvailable: car.isAvailable,
    });
    setShowForm(true);
  };

  // ✅ Add new car form
  const handleAddCarClick = () => {
    setEditingCarId(null);
    setNewCar({
      make: "",
      model: "",
      year: "",
      pricePerDay: "",
      location: "",
      imageUrl: "",
      isAvailable: true,
    });
    setShowForm(true);
  };

  const handleFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNewCar((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  // ✅ Save car (POST / PUT)
  const handleFormSubmit = (e) => {
    e.preventDefault();
    const method = editingCarId ? "PUT" : "POST";
    const url = editingCarId ? `${API_URL}/${editingCarId}` : API_URL;

    fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newCar),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to save car");
        return res.json();
      })
      .then(() => {
        fetchCars();
        setNewCar({
          make: "",
          model: "",
          year: "",
          pricePerDay: "",
          location: "",
          imageUrl: "",
          isAvailable: true,
        });
        setShowForm(false);
        setEditingCarId(null);
      })
      .catch((err) => alert(err.message));
  };

  if (loading) return <p>Loading cars...</p>;
  if (error) return <p style={{ color: "red" }}>Error: {error}</p>;

  return (
    <div className="manage-cars-container">
      <h2>Manage Cars</h2>
      <button className="add-car-button" onClick={handleAddCarClick}>
        Add New Car
      </button>

      {showForm && (
        <form className="add-car-form" onSubmit={handleFormSubmit}>
          <input
            type="text"
            name="make"
            placeholder="Make"
            value={newCar.make}
            onChange={handleFormChange}
            required
          />
          <input
            type="text"
            name="model"
            placeholder="Model"
            value={newCar.model}
            onChange={handleFormChange}
            required
          />
          <input
            type="number"
            name="year"
            placeholder="Year"
            value={newCar.year}
            onChange={handleFormChange}
            required
          />
          <input
            type="number"
            name="pricePerDay"
            placeholder="Price Per Day"
            value={newCar.pricePerDay}
            onChange={handleFormChange}
            required
          />
          <input
            type="text"
            name="location"
            placeholder="Location"
            value={newCar.location}
            onChange={handleFormChange}
            required
          />

          <label>
            <input
              type="checkbox"
              name="isAvailable"
              checked={newCar.isAvailable}
              onChange={handleFormChange}
            />{" "}
            Available
          </label>
          <button type="submit">
            {editingCarId ? "Update Car" : "Save Car"}
          </button>
        </form>
      )}

      <table className="car-table">
        <thead>
          <tr>
            <th>Make</th>
            <th>Model</th>
            <th>Year</th>
            <th>Price</th>
            <th>Location</th>
            <th>Availability</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {cars.map((car) => (
            <tr key={car.vehicleId}>
              <td>{car.make}</td>
              <td>{car.model}</td>
              <td>{car.year}</td>
              <td>₹{car.pricePerDay}</td>
              <td>{car.location}</td>
              <td>
                <span
                  className={
                    car.isAvailable ? "status-active" : "status-inactive"
                  }
                >
                  {car.isAvailable ? "Available" : "Unavailable"}
                </span>
              </td>
              <td>
                <div className="action-buttons">
                  <button
                    className="action-button edit-button"
                    onClick={() => handleEdit(car)}
                  >
                    Edit
                  </button>
                  <button
                    className="action-button delete-button"
                    onClick={() => handleDelete(car.vehicleId)}
                  >
                    Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ManageCars;
