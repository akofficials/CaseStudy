import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./reviewpage.css";

const ReviewPage = () => {
  const { vehicleId } = useParams();
  const [review, setReview] = useState("");
  const [carDetails, setCarDetails] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const car = JSON.parse(localStorage.getItem("selectedCar"));
    if (car && car.vehicleId.toString() === vehicleId) {
      setCarDetails(car);
    }
  }, [vehicleId]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const userName = localStorage.getItem("userName") || "Anonymous User";
    const userEmail = localStorage.getItem("userEmail") || "No Email";

    const newReview = {
      vehicleId,
      car: carDetails,
      review,
      userName,
      userEmail,
      date: new Date().toLocaleString(),
    };

    // ✅ Save to localStorage
    const storedReviews = JSON.parse(localStorage.getItem("reviews")) || [];
    storedReviews.push(newReview);
    localStorage.setItem("reviews", JSON.stringify(storedReviews));

    setReview("");
    alert("✅ Review submitted successfully!");

    // ✅ Redirect back to user profile after submit
    navigate("/user-profile");
  };

  return (
    <div className="review-page-container">
      <h2>
        Write a Review for{" "}
        {carDetails
          ? `${carDetails.make} ${carDetails.model}`
          : `Vehicle ${vehicleId}`}
      </h2>
      <form onSubmit={handleSubmit} className="review-form">
        <textarea
          className="review-textarea"
          placeholder="Write your review here..."
          value={review}
          onChange={(e) => setReview(e.target.value)}
          required
        />
        <button type="submit" className="submit-btn">
          Submit Review
        </button>
      </form>
    </div>
  );
};

export default ReviewPage;
