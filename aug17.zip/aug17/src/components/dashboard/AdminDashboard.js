import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ManageUsers from "./ManageUsers";
import ManageCars from "./ManageCars";
import "./dashboard.css";
import Bookings from "./Bookings";

// ✅ Feedback Component
const Feedback = () => {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    const storedReviews = JSON.parse(localStorage.getItem("reviews")) || [];
    setReviews(storedReviews);
  }, []);

  const handleDelete = (index) => {
    const updatedReviews = reviews.filter((_, i) => i !== index);
    setReviews(updatedReviews);
    localStorage.setItem("reviews", JSON.stringify(updatedReviews));
  };

  return (
    <div>
      {reviews.length === 0 ? (
        <p>No feedback submitted yet.</p>
      ) : (
        <ul style={{ listStyle: "none", padding: 0 }}>
          {reviews.map((r, index) => (
            <li
              key={index}
              style={{
                border: "1px solid #ccc",
                borderRadius: "8px",
                padding: "10px",
                marginBottom: "10px",
                background: "#f9f9f9",
              }}
            >
              <p>
                <strong>User:</strong> {r.user}
              </p>
              <p>
                <strong>Car:</strong> {r.car?.make} {r.car?.model} (
                {r.car?.year})
              </p>
              <p>
                <strong>Review:</strong> {r.review}
              </p>
              <p>
                <em>{r.date}</em>
              </p>
              <button
                onClick={() => handleDelete(index)}
                style={{
                  marginTop: "5px",
                  padding: "5px 10px",
                  background: "#e74c3c",
                  color: "white",
                  border: "none",
                  borderRadius: "5px",
                  cursor: "pointer",
                }}
              >
                ❌ Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("users");
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/");
  };

  const renderContent = () => {
    switch (activeTab) {
      case "users":
        return <ManageUsers />;
      case "cars":
        return <ManageCars />;
      case "bookings":
        return <Bookings />;
      case "feedback":
        return <Feedback />;
      default:
        return null;
    }
  };

  return (
    <div className="dashboard-container">
      <div className="sidebar">
        <div>
          <h2>Admin Panel</h2>
          <div className="nav-buttons">
            <button
              className="nav-button"
              onClick={() => setActiveTab("users")}
            >
              Manage Users
            </button>
            <button className="nav-button" onClick={() => setActiveTab("cars")}>
              Vehicle Record
            </button>
            <button
              className="nav-button"
              onClick={() => setActiveTab("bookings")}
            >
              Reservations
            </button>
            <button
              className="nav-button"
              onClick={() => setActiveTab("feedback")}
            >
              User Feedback
            </button>
          </div>
        </div>
        <button className="nav-button" onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div className="content">
        <h1>{activeTab.toUpperCase().replace(/_/g, " ")}</h1>
        {renderContent()}
      </div>
    </div>
  );
};

export default AdminDashboard;
