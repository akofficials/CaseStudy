import axios from "axios";

const apiNoAuth = axios.create({
  baseURL: process.env.REACT_APP_API_BASE || "http://localhost:3000/api",
  withCredentials: false,
});

// IMPORTANT: Do NOT add Authorization headers here.
export default apiNoAuth;
