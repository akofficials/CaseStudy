import apiNoAuth from "../api/noAuthAxios";

/**
 * Attempts admin login with tolerant variations:
 * - Endpoints: /admin/login and /Admin/Login
 * - Body shapes: {email,password} and {userName,password}
 * Returns the token string if successful, throws otherwise.
 */
export async function loginAsAdminCompatible({ email, password }) {
  const endpoints = ["/admin/login", "/Admin/Login"];
  const bodies = [
    { email, password },
    { userName: email, password }, // some backends expect "userName"
  ];

  // Try each combination until one succeeds
  let lastError;
  for (const url of endpoints) {
    for (const body of bodies) {
      try {
        const res = await apiNoAuth.post(url, body);
        const token = res?.data?.token ?? res?.data;
        if (typeof token !== "string" || !token) {
          throw new Error("No token returned");
        }
        return token;
      } catch (err) {
        lastError = err;
        // continue trying next combination
      }
    }
  }

  // If all attempts failed, surface best error info
  const serverMsg =
    lastError?.response?.data?.message ||
    lastError?.response?.data?.error ||
    lastError?.message ||
    "Login failed";
  throw new Error(serverMsg);
}
