import React, { useEffect, useState } from "react";
import api from "../../api/axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Profile.css";

const Profile = () => {
  const navigate = useNavigate();
  const [userDetails, setUserDetails] = useState(null);
  const [documents, setDocuments] = useState({
    aadhar: null,
    license: null,
    insurance: null,
  });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchUserDetails();
    fetchDocuments();
  }, []);

  const fetchUserDetails = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;
      jwtDecode(token); // decoding but not used yet
      const res = await api.get(`/user/profile`);
      setUserDetails(res.data);
    } catch (err) {
      console.error("Error fetching user details:", err);
    }
  };

  const fetchDocuments = async () => {
    try {
      const res = await api.get("/user/documents");
      setStatus(res.data);
    } catch (err) {
      if (err.response && err.response.status === 404) {
        setStatus(null);
      } else {
        console.error("Error fetching documents:", err);
      }
    }
  };

  const handleFileChange = (e) => {
    setDocuments({ ...documents, [e.target.name]: e.target.files[0] });
  };

  const handleUpload = async (e) => {
    e.preventDefault();

    if (!documents.aadhar || !documents.license) {
      alert("Aadhar and License documents are mandatory.");
      return;
    }

    const formData = new FormData();
    formData.append("AadharImage", documents.aadhar);
    formData.append("LicenseImage", documents.license);
    if (documents.insurance) {
      formData.append("InsuranceImage", documents.insurance);
    }

    try {
      setLoading(true);
      await api.post("/user/documents", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMessage("Documents uploaded successfully!");
      fetchDocuments();
    } catch (err) {
      console.error("Error uploading documents:", err);
      setMessage(err.response?.data || "Failed to upload documents.");
    } finally {
      setLoading(false);
    }
  };

  const getBadge = () => {
    if (!status)
      return <span className="badge bg-secondary">Not Uploaded</span>;
    if (status.isApproved)
      return <span className="badge bg-success">Approved</span>;
    if (status.status === "Pending")
      return <span className="badge bg-warning text-dark">Pending</span>;
    return <span className="badge bg-danger">Rejected</span>;
  };

  // ---------------- Header ----------------
  const Header = () => (
    <header className="bg-dark text-white py-3 px-5 d-flex justify-content-between align-items-center shadow-sm">
      <h3 className="m-0">SpeedUp</h3>
      <div>
        <button
          className="btn btn-outline-light me-2"
          onClick={() => navigate("/")}
        >
          Home
        </button>
        <button
          className="btn btn-outline-light me-2"
          onClick={() => navigate("/cars")}
        >
          Cars
        </button>
        <button
          className="btn btn-danger"
          onClick={() => {
            localStorage.removeItem("token");
            navigate("/user/login");
          }}
        >
          Logout
        </button>
      </div>
    </header>
  );

  // ---------------- Footer ----------------
  const Footer = () => (
    <footer className="bg-dark text-white py-3 mt-5">
      <div className="container text-center">
        <p className="mb-0">© 2025 SpeedUp. All rights reserved.</p>
      </div>
    </footer>
  );

  return (
    <div style={{ backgroundColor: "#f8f9fa", minHeight: "100vh" }}>
      <Header />

      <div className="container mt-5 mb-5">
        <h2 className="text-center text-danger mb-4">
          User Profile & Document Upload
        </h2>

        {/* User Details */}
        {userDetails && (
          <div className="card shadow-sm mb-4 border border-primary animate__animated animate__fadeIn">
            <div className="card-body">
              <h5 className="mb-3 text-primary">User Details</h5>
              <p>
                <strong>Name:</strong> {userDetails.firstName}{" "}
                {userDetails.lastName}
              </p>
              <p>
                <strong>Email:</strong> {userDetails.email}
              </p>
              <p>
                <strong>Phone:</strong> {userDetails.phoneNumber}
              </p>
            </div>
          </div>
        )}

        {message && (
          <div className="alert alert-info text-center">{message}</div>
        )}

        {/* Upload Form */}
        <form
          onSubmit={handleUpload}
          className="border border-danger rounded p-4 shadow-lg bg-light animate__animated animate__fadeInUp"
        >
          <h5 className="mb-3 text-primary">Documents Upload</h5>
          <div className="mb-4">
            <label className="form-label fw-bold" style={{ color: "black" }}>
              Upload Aadhar (Mandatory)
            </label>
            <input
              type="file"
              name="aadhar"
              className="form-control"
              accept="image/*,application/pdf"
              onChange={handleFileChange}
              required
            />
          </div>

          <div className="mb-4">
            <label className="form-label fw-bold" style={{ color: "black" }}>
              Upload License (Mandatory)
            </label>
            <input
              type="file"
              name="license"
              className="form-control"
              accept="image/*,application/pdf"
              onChange={handleFileChange}
              required
            />
          </div>

          <div className="mb-4">
            <label className="form-label fw-bold" style={{ color: "black" }}>
              Upload Insurance (Optional)
            </label>
            <input
              type="file"
              name="insurance"
              className="form-control"
              accept="image/*,application/pdf"
              onChange={handleFileChange}
            />
          </div>

          <div className="mb-4">
            <label className="form-label fw-bold" style={{ color: "black" }}>
              Status
            </label>
            <div>{getBadge()}</div>
          </div>

          <div className="text-center">
            <button
              className="btn btn-danger w-50"
              type="submit"
              disabled={loading}
            >
              {loading ? "Uploading..." : "Upload Documents"}
            </button>
          </div>
        </form>
      </div>

      <Footer />
    </div>
  );
};

export default Profile;
