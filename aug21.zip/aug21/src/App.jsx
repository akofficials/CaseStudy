import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// User
import Profile from "./components/UserPanel/Profile";
import Home from "./pages/user/Home";
import UserLogin from "./pages/auth/UserLogin";
import UserRegister from "./pages/auth/UserRegister";
import CarList from "./pages/user/CarList";
import BookingHistory from "./pages/user/BookingHistory";
import Booking from "./pages/user/Booking";
import Payment from "./pages/Payment";

// Admin
import AdminLogin from "./pages/auth/AdminLogin";
import AdminRegister from "./pages/auth/AdminRegister";
import AdminLayout from "./pages/admin/AdminLayout";
import Dashboard from "./pages/admin/Dashboard";
import Cars from "./pages/admin/Cars";
import Bookings from "./pages/admin/Bookings";
import Payments from "./pages/admin/Payments";
import Documents from "./pages/admin/Documents";
import Users from "./pages/admin/Users";

// Agent
import AgentLayout from "./layouts/AgentLayout";
import AgentDashboard from "./pages/agent/AgentDashboard";
import AgentLogin from "./pages/agent/AgentLogin";
import ProtectedAgent from "./routes/ProtectedAgent";

function App() {
  return (
    <Router>
      <Routes>
        {/* Public */}
        <Route path="/" element={<Home />} />
        <Route path="/cars" element={<CarList />} />
        <Route path="/user/profile" element={<Profile />} />
        <Route path="/user/login" element={<UserLogin />} />
        <Route path="/user/register" element={<UserRegister />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="/booking-history" element={<BookingHistory />} />
        <Route path="/payment" element={<Payment />} />

        {/* Admin Auth */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin/register" element={<AdminRegister />} />

        {/* Admin Layout (optionally wrap with ProtectedAdmin) */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="cars" element={<Cars />} />
          <Route path="bookings" element={<Bookings />} />
          <Route path="payments" element={<Payments />} />
          <Route path="documents" element={<Documents />} />
          <Route path="users" element={<Users />} />
        </Route>

        {/* Agent Auth */}
        <Route path="/agent/login" element={<AgentLogin />} />

        {/* Agent Layout (protected) */}
        <Route
          path="/agent"
          element={
            <ProtectedAgent>
              <AgentLayout />
            </ProtectedAgent>
          }
        >
          <Route index element={<AgentDashboard />} />
          <Route path="dashboard" element={<AgentDashboard />} />
          <Route path="cars" element={<Cars />} />
          <Route path="bookings" element={<Bookings />} />
          <Route path="documents" element={<Documents />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
