import React, { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Admin.css";

const AdminLayout = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false); // sidebar on mobile

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    navigate("/", { replace: true }); // go home
  };

  const closeIfMobile = () => setOpen(false);

  return (
    <div className="rg-shell">
      {/* Sidebar */}
      <aside className={`rg-sidebar ${open ? "is-open" : ""}`}>
        <div className="rg-sidebar__brand">
          <div className="rg-badge">SP</div>
          <div className="rg-brand-text">
            <strong>SpeedUp</strong>
            <span>Admin</span>
          </div>
        </div>

        <nav className="rg-sidebar__nav">
          <NavLink
            to="/admin/users"
            className={({ isActive }) =>
              `rg-navlink ${isActive ? "active" : ""}`
            }
            onClick={closeIfMobile}
          >
            <span className="rg-ico">👥</span> Manage Users
          </NavLink>
          <NavLink
            to="/admin/cars"
            className={({ isActive }) =>
              `rg-navlink ${isActive ? "active" : ""}`
            }
            onClick={closeIfMobile}
          >
            <span className="rg-ico">🚗</span> Manage Cars
          </NavLink>
          <NavLink
            to="/admin/bookings"
            className={({ isActive }) =>
              `rg-navlink ${isActive ? "active" : ""}`
            }
            onClick={closeIfMobile}
          >
            <span className="rg-ico">🗓️</span> Manage Bookings
          </NavLink>
          <NavLink
            to="/admin/payments"
            className={({ isActive }) =>
              `rg-navlink ${isActive ? "active" : ""}`
            }
            onClick={closeIfMobile}
          >
            <span className="rg-ico">💳</span> Manage Payments
          </NavLink>
          <NavLink
            to="/admin/documents"
            className={({ isActive }) =>
              `rg-navlink ${isActive ? "active" : ""}`
            }
            onClick={closeIfMobile}
          >
            <span className="rg-ico">📄</span> Manage Documents
          </NavLink>
        </nav>

        <button className="rg-logout" onClick={handleLogout}>
          Logout
        </button>
      </aside>

      {/* Page Content */}
      <main className="rg-main">
        <div className="rg-topbar">
          <button
            className="rg-burger"
            onClick={() => setOpen((s) => !s)}
            aria-label="Toggle sidebar"
          >
            <span />
            <span />
            <span />
          </button>
          <h1 className="rg-topbar__title">Admin</h1>
          <div className="rg-topbar__spacer" />
          <button
            className="rg-topbar__logout d-inline d-lg-none"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>

        <div className="rg-content container-fluid">
          <Outlet />
        </div>
      </main>

      {open && <div className="rg-backdrop" onClick={() => setOpen(false)} />}
    </div>
  );
};

export default AdminLayout;
