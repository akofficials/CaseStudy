// routes/ProtectedAgent.jsx (role-aware)
import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { jwtDecode } from "jwt-decode";

const ProtectedAgent = ({ children }) => {
  const token = localStorage.getItem("adminToken");
  const location = useLocation();
  if (!token)
    return <Navigate to="/agent/login" state={{ from: location }} replace />;

  try {
    const decoded = jwtDecode(token);
    const roles =
      decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] ||
      decoded.role ||
      decoded.roles ||
      [];
    const list = Array.isArray(roles)
      ? roles.map((r) => String(r).toLowerCase())
      : [String(roles).toLowerCase()];
    if (!list.includes("admin") && !list.includes("agent")) {
      return <Navigate to="/agent/login" replace />;
    }
  } catch {
    return <Navigate to="/agent/login" replace />;
  }
  return children;
};

export default ProtectedAgent;
