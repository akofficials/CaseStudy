import React from 'react';
import { Routes, Route } from 'react-router-dom';
import UserDashboard from '../pages/user/UserDashboard';
import Home from '../pages/user/Home';

const UserRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/home" element={<Home />} />
      <Route path="/user/dashboard" element={<UserDashboard />} />
      {/* You'll add other routes here like /user/bookings, /user/payments, etc. */}
    </Routes>
  );
};

export default UserRoutes;
