import React, { useEffect, useMemo, useState } from "react";
import api from "../../api/axios";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./CarList.css";
import "./Home.css";

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const CarList = () => {
  const navigate = useNavigate();
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // Location is showcase-only (doesn't affect filtering or API)
  const [filters, setFilters] = useState({ seats: "", type: "", location: "" });

  useEffect(() => {
    fetchCars();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchCars = async () => {
    setLoading(true);
    setErr("");
    try {
      let url = "/Car";
      const queryParams = [];
      if (filters.type)
        queryParams.push(`type=${encodeURIComponent(filters.type)}`);
      if (filters.seats)
        queryParams.push(`seats=${encodeURIComponent(filters.seats)}`);
      // NOTE: location is showcase-only — do NOT include in query

      if (queryParams.length) url += "?" + queryParams.join("&");

      const res = await api.get(url);
      setCars(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Error fetching cars", err);
      setErr("Failed to fetch cars");
    } finally {
      setLoading(false);
    }
  };

  const filteredCars = useMemo(() => {
    let updated = [...cars];

    if (filters.seats) {
      updated = updated.filter(
        (c) => Number(c.seats) === Number(filters.seats)
      );
    }
    if (filters.type) {
      updated = updated.filter((c) => c.type === filters.type);
    }
    // NOTE: location is showcase-only — do NOT filter by it

    return updated;
  }, [cars, filters]);

  const handleFilterChange = (e) => {
    setFilters((s) => ({ ...s, [e.target.name]: e.target.value }));
  };

  const resetFilters = () => setFilters({ seats: "", type: "", location: "" });

  // Check documents before booking → then navigate to Booking with car
  const handleBookNow = async (car) => {
    try {
      const res = await api.get("/user/documents");
      const document = res.data;

      if (!document || !document.isApproved) {
        alert(
          "Your documents are not approved yet. Please upload/await approval."
        );
        navigate("/user/profile");
        return;
      }
      navigate("/booking", { state: { car } });
    } catch (err) {
      console.error("Error checking documents", err);
      alert("Please upload your documents before booking.");
      navigate("/user/profile");
    }
  };

  // Topbar / Footer to match Booking
  const Topbar = () => (
    <div className="rg-topbar container-fluid">
      <div className="container d-flex align-items-center justify-content-between">
        <div className="d-flex align-items-center gap-2">
          <div className="rg-badge">SP</div>
          <div className="rg-brand">SpeedUp</div>
        </div>
        <div className="d-flex align-items-center gap-2">
          <button
            className="rg-btn rg-btn--ghost d-none d-sm-inline"
            onClick={() => navigate("/")}
          >
            Home
          </button>
          <button
            className="rg-btn rg-btn--ghost d-none d-sm-inline"
            onClick={() => navigate("/user/profile")}
          >
            Profile
          </button>
          <button
            className="rg-btn rg-btn--danger"
            onClick={() => {
              localStorage.removeItem("token");
              navigate("/", { replace: true }); // redirect to Home on logout
            }}
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );

  const Footer = () => (
    <footer className="rg-footer">
      <div className="container text-center">
        © 2025 SpeedUp. All rights reserved.
      </div>
    </footer>
  );

  return (
    <div className="rg-page">
      <Topbar />

      <div className="container py-4 py-md-5">
        <h2 className="rg-title text-center mb-3">Available Cars</h2>
        <p className="rg-sub text-center mb-4">
          Pick your ride. Filter by seats, fuel type, and location.
        </p>

        {/* Filters */}
        <div className="rg-filters d-flex flex-wrap justify-content-center gap-2 gap-md-3 mb-3">
          <div className="rg-select">
            <select
              name="seats"
              onChange={handleFilterChange}
              value={filters.seats}
              aria-label="Filter by seats"
            >
              <option value="">Filter by Seats</option>
              <option value="5">5 Seater</option>
              <option value="7">7 Seater</option>
            </select>
          </div>

          <div className="rg-select">
            <select
              name="type"
              onChange={handleFilterChange}
              value={filters.type}
              aria-label="Filter by fuel type"
            >
              <option value="">Filter by Fuel Type</option>
              <option value="Petrol">Petrol</option>
              <option value="Diesel">Diesel</option>
              <option value="EV">EV</option>
            </select>
          </div>

          {/* Showcase-only Location filter (doesn't change results) */}
          <div className="rg-select">
            <select
              name="location"
              onChange={handleFilterChange}
              value={filters.location}
              aria-label="Filter by location (showcase only)"
            >
              <option value="">Filter by Location</option>
              <option value="Chennai">Chennai</option>
              <option value="Madurai">Madurai</option>
              <option value="Coimbatore">Coimbatore</option>
            </select>
          </div>

          <button className="rg-btn" onClick={fetchCars}>
            Apply Filter
          </button>
          <button
            className="rg-btn rg-btn--ghost"
            onClick={() => {
              resetFilters();
              fetchCars();
            }}
          >
            Reset
          </button>
        </div>

        {/* Grid */}
        {err && (
          <div
            className="alert alert-danger py-2 px-3 my-2 text-center"
            role="alert"
          >
            {err}
          </div>
        )}

        <div className="row g-3 g-md-4">
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div className="col-12 col-sm-6 col-lg-4" key={`skel-${i}`}>
                <div className="rg-card rg-car h-100">
                  <div className="rg-media skel" />
                  <div className="rg-car__body">
                    <div className="rg-skel w-75 mb-2" />
                    <div className="rg-skel w-50 mb-2" />
                    <div className="rg-skel w-25 mb-3" />
                    <div
                      className="rg-skel w-100"
                      style={{ height: 36, borderRadius: 10 }}
                    />
                  </div>
                </div>
              </div>
            ))
          ) : filteredCars.length === 0 ? (
            <div className="col-12">
              <div className="rg-empty text-center">
                <div className="rg-empty__title">No cars found</div>
                <div className="rg-empty__sub">
                  Try different filters or reset.
                </div>
              </div>
            </div>
          ) : (
            filteredCars.map((car) => {
              const city = car.location || car.city || car.pickupCity;
              return (
                <div className="col-12 col-sm-6 col-lg-4" key={car.id}>
                  <div className="rg-card rg-car h-100">
                    <div className="rg-media">
                      {car.imageUrl ? (
                        <img
                          src={car.imageUrl}
                          alt={`${car.brand} ${car.model}`}
                        />
                      ) : (
                        <div className="rg-media__ph">🚗</div>
                      )}
                    </div>
                    <div className="rg-car__body">
                      <h5 className="rg-car__title">
                        {car.brand} {car.model}
                      </h5>

                      <div className="rg-car__meta">
                        {city && <span className="rg-chip">{city}</span>}
                        <span className="rg-chip">{car.type}</span>
                        <span className="rg-chip">{car.seats} seats</span>
                      </div>

                      <div className="rg-price">
                        {inr.format(car.pricePerDay)} <span>/ day</span>
                      </div>

                      <button
                        className="rg-btn w-100"
                        onClick={() => handleBookNow(car)}
                      >
                        Book Now
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default CarList;
