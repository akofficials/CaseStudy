import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Home.css";

function Home() {
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [username, setUsername] = useState("");

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;
    try {
      const decoded = jwtDecode(token);
      const userName =
        decoded["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"];
      setUsername(userName || "");
      localStorage.setItem("userName", userName || "");
    } catch {
      console.error("Invalid token");
      localStorage.removeItem("token");
      setUsername("");
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setUsername("");
    navigate("/", { replace: true }); // ⬅ go home
  };

  const goCars = () => {
    const token = localStorage.getItem("token");
    token ? navigate("/cars") : navigate("/user/login");
  };

  const scrollTo = (id) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <>
      {/* NAVBAR */}
      <header className={`rg-nav ${isScrolled ? "rg-nav--scrolled" : ""}`}>
        <div className="container d-flex align-items-center justify-content-between py-2">
          <div className="d-flex align-items-center gap-2">
            <div className="rg-badge">SP</div>
            <button className="rg-logo btn p-0" onClick={() => navigate("/")}>
              SpeedUp
            </button>
          </div>

          {/* Desktop */}
          <nav className="d-none d-md-flex align-items-center gap-3">
            <button className="rg-link" onClick={() => scrollTo("why")}>
              Why
            </button>
            <button className="rg-link" onClick={() => scrollTo("reviews")}>
              Reviews
            </button>
            <button className="rg-link" onClick={() => scrollTo("faq")}>
              FAQ
            </button>
            <button className="rg-link" onClick={() => scrollTo("contact")}>
              Contact
            </button>

            {username ? (
              <>
                <span className="rg-chip">Hi, {username.split(" ")[0]}</span>
                <button
                  className="btn btn-outline-light"
                  onClick={() => navigate("/booking-history")}
                >
                  Bookings
                </button>
                <button
                  className="btn btn-outline-light"
                  onClick={() => navigate("/user/profile")}
                >
                  Profile
                </button>
                <button className="btn btn-primary" onClick={goCars}>
                  Browse Cars
                </button>
                <button className="btn btn-danger" onClick={handleLogout}>
                  Logout
                </button>
              </>
            ) : (
              <>
                <div className="d-flex gap-2">
                  <button
                    className="btn btn-dark"
                    onClick={() => navigate("/user/login")}
                  >
                    User Login
                  </button>
                  <button
                    className="btn btn-secondary"
                    onClick={() => navigate("/admin/login")}
                  >
                    Admin Login
                  </button>
                  <button
                    className="btn btn-warning text-dark"
                    onClick={() => navigate("/agent/login")}
                  >
                    Rental Agent Login
                  </button>
                </div>
                <button
                  className="btn btn-outline-light"
                  onClick={() => navigate("/user/register")}
                >
                  Sign up
                </button>
                <button className="btn btn-primary" onClick={goCars}>
                  Browse Cars
                </button>
              </>
            )}
          </nav>

          {/* Mobile */}
          <button
            className="btn btn-outline-light d-md-none"
            onClick={() => setShowMenu((v) => !v)}
            aria-label="Open menu"
          >
            <i className="bi bi-list" />
          </button>
        </div>

        {/* Mobile sheet */}
        {showMenu && (
          <div className="rg-sheet d-md-none">
            <div className="container py-3 d-grid gap-2">
              {username ? (
                <>
                  <div className="text-white-50">Signed in as</div>
                  <div className="fw-semibold">{username}</div>
                  <hr className="rg-hr" />
                  <button
                    className="rg-sheet-link"
                    onClick={() => navigate("/booking-history")}
                  >
                    Bookings
                  </button>
                  <button
                    className="rg-sheet-link"
                    onClick={() => navigate("/user/profile")}
                  >
                    Profile
                  </button>
                  <button className="rg-sheet-link" onClick={goCars}>
                    Browse Cars
                  </button>
                  <hr className="rg-hr" />
                  <button className="btn btn-danger" onClick={handleLogout}>
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <div className="d-grid gap-2">
                    <button
                      className="btn btn-dark"
                      onClick={() => navigate("/user/login")}
                    >
                      User Login
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => navigate("/admin/login")}
                    >
                      Admin Login
                    </button>
                    <button
                      className="btn btn-warning text-dark"
                      onClick={() => navigate("/agent/login")}
                    >
                      Rental Agent Login
                    </button>
                  </div>
                  <div className="d-grid gap-2 mt-2">
                    <button
                      className="btn btn-outline-light"
                      onClick={() => navigate("/user/register")}
                    >
                      Sign up
                    </button>
                    <button className="btn btn-primary" onClick={goCars}>
                      Browse Cars
                    </button>
                  </div>
                </>
              )}
              <hr className="rg-hr" />
              <div className="d-flex flex-wrap gap-2">
                <button className="rg-tag" onClick={() => scrollTo("why")}>
                  Why
                </button>
                <button className="rg-tag" onClick={() => scrollTo("reviews")}>
                  Reviews
                </button>
                <button className="rg-tag" onClick={() => scrollTo("faq")}>
                  FAQ
                </button>
                <button className="rg-tag" onClick={() => scrollTo("contact")}>
                  Contact
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="rg-hero">
        <div className="container text-center">
          <h1 className="rg-hero-title">
            Keys to freedom, <span className="text-primary">anytime</span>.
          </h1>
          <p className="rg-hero-sub">
            Reliable cars. Zero drama. Instant checkout.
          </p>

          <div className="d-flex flex-column flex-md-row gap-2 justify-content-center mt-3">
            <button className="btn btn-primary btn-lg" onClick={goCars}>
              Find a Car
            </button>
            <button
              className="btn btn-outline-light btn-lg"
              onClick={() => scrollTo("why")}
            >
              Why SpeedUp?
            </button>
          </div>

          <div className="rg-stats mt-4">
            <div className="rg-stat">
              <div className="rg-stat-num">5k+</div>
              <div className="rg-stat-label">Happy Drivers</div>
            </div>
            <div className="rg-stat">
              <div className="rg-stat-num">200+</div>
              <div className="rg-stat-label">Cities Covered</div>
            </div>
            <div className="rg-stat">
              <div className="rg-stat-num">4.9★</div>
              <div className="rg-stat-label">Avg Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* BRANDS STRIP */}

      {/* WHY */}
      <section id="why" className="rg-section container">
        <h2 className="rg-section-title text-center">Why roll with us</h2>
        <div className="row g-4 mt-2">
          <div className="col-md-4">
            <div className="rg-card h-100">
              <i className="bi bi-bolt-fill rg-ico" />
              <h5>Lightning-fast booking</h5>
              <p>From search to keys in under 60s. Tap tap vroom.</p>
            </div>
          </div>
          <div className="col-md-4">
            <div className="rg-card h-100">
              <i className="bi bi-ev-station-fill rg-ico" />
              <h5>Every vibe, every ride</h5>
              <p>Hatchbacks, SUVs, EVs & luxe—pick your mood for the day.</p>
            </div>
          </div>
          <div className="col-md-4">
            <div className="rg-card h-100">
              <i className="bi bi-shield-lock-fill rg-ico" />
              <h5>Built-in trust</h5>
              <p>Verified vehicles, secure payments, full transparency.</p>
            </div>
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section id="reviews" className="rg-section container">
        <h2 className="rg-section-title text-center">What drivers say</h2>
        <div className="row g-4 mt-2">
          {[
            {
              name: "Arjun Nair",
              text: "Car was spotless. Pickup was a breeze. 10/10.",
            },
            {
              name: "Swathi R.",
              text: "Solid pricing. Support team is actually helpful 😭.",
            },
            {
              name: "Kishore B.",
              text: "Booked in minutes and hit the road. Smooth.",
            },
            { name: "Gayathri", text: "Best cars, best prices. I’m a fan." },
          ].map((r, i) => (
            <div className="col-md-6" key={i}>
              <div className="rg-review">
                <p className="mb-2">“{r.text}”</p>
                <div className="text-primary fw-semibold">— {r.name}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="rg-section container">
        <h2 className="rg-section-title text-center">FAQ</h2>
        <div className="accordion mt-3" id="faqAcc">
          {[
            {
              q: "Do I need a deposit?",
              a: "Depends on the car category and city. Shown upfront before payment.",
            },
            {
              q: "Can I cancel?",
              a: "Yep. Free within the grace window. After that, small fee applies.",
            },
            {
              q: "Are EV chargers included?",
              a: "Many pickups have chargers on-site. Details listed on each car.",
            },
          ].map((f, i) => (
            <div className="accordion-item rg-acc" key={i}>
              <h2 className="accordion-header" id={`h${i}`}>
                <button
                  className="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target={`#c${i}`}
                  aria-expanded="false"
                  aria-controls={`c${i}`}
                >
                  {f.q}
                </button>
              </h2>
              <div
                id={`c${i}`}
                className="accordion-collapse collapse"
                aria-labelledby={`h${i}`}
                data-bs-parent="#faqAcc"
              >
                <div className="accordion-body">{f.a}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="rg-section container">
        <h2 className="rg-section-title text-center">Contact</h2>
        <div className="row g-4 mt-2 align-items-stretch">
          <div className="col-md-6">
            <div className="rg-card h-100">
              <h5 className="mb-3">SpeedUp HQ</h5>
              <p className="mb-1">
                <strong>📍 Address:</strong> 123 Main Street, Chennai, India
              </p>
              <p className="mb-1">
                <strong>📧 Email:</strong> contact@SpeedUp.com
              </p>
              <p className="mb-0">
                <strong>📞 Phone:</strong> +91 98765 43210
              </p>
            </div>
          </div>
          <div className="col-md-3"></div>
        </div>
      </section>

      {/* CTA STRIP */}
      <section className="rg-cta">
        <div className="container d-flex flex-column flex-md-row align-items-center justify-content-between gap-3">
          <div>
            <h3 className="m-0">Ready to roll?</h3>
            <div className="text-white-50">Grab the keys in a few taps.</div>
          </div>
          <div className="d-flex gap-2">
            {username ? (
              <button
                className="btn btn-light"
                onClick={() => navigate("/booking-history")}
              >
                My bookings
              </button>
            ) : (
              <button
                className="btn btn-light"
                onClick={() => navigate("/user/register")}
              >
                Create account
              </button>
            )}
            <button className="btn btn-outline-light" onClick={goCars}>
              Browse Cars
            </button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="rg-footer">
        <div className="container d-flex flex-column flex-md-row align-items-center justify-content-between gap-2">
          <div>© {new Date().getFullYear()} SpeedUp</div>
          <div className="d-flex gap-3">
            <button className="rg-link" onClick={() => scrollTo("why")}>
              Why
            </button>
            <button className="rg-link" onClick={() => scrollTo("faq")}>
              FAQ
            </button>
            <button className="rg-link" onClick={() => scrollTo("contact")}>
              Contact
            </button>
          </div>
        </div>
      </footer>
    </>
  );
}

export default Home;
