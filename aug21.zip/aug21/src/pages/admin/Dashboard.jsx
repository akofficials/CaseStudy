// src/pages/admin/Dashboard.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../../api/axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Dashboard.css";

const Dashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCars: 0,
    totalBookings: 0,
    totalPayments: 0,
  });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await api.get("/admin/dashboard-stats");
        setStats(response.data || {});
      } catch (error) {
        console.error("Error fetching admin stats:", error);
        setErr("Failed to load stats");
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const cards = [
    {
      key: "totalUsers",
      label: "Users",
      variant: "users",
      value: stats.totalUsers ?? 0,
    },
    {
      key: "totalCars",
      label: "Cars",
      variant: "cars",
      value: stats.totalCars ?? 0,
    },
    {
      key: "totalBookings",
      label: "Bookings",
      variant: "bookings",
      value: stats.totalBookings ?? 0,
    },
    {
      key: "totalPayments",
      label: "Payments",
      variant: "payments",
      value: stats.totalPayments ?? 0,
    },
  ];

  return (
    <div className="rg-admin">
      <div className="rg-admin__inner container-fluid">
        <header className="rg-admin__header">
          <h2 className="rg-title">Welcome, Admin</h2>
          {err && (
            <div className="alert alert-danger py-2 px-3 mb-0">{err}</div>
          )}
        </header>

        {/* Stats */}
        <div className="row g-3 mt-2">
          {cards.map((c) => (
            <div key={c.key} className="col-12 col-sm-6 col-lg-3">
              <div className={`stat-card stat-card--${c.variant}`}>
                <div className="stat-card__label">{c.label}</div>
                <div className="stat-card__value">
                  {loading ? <span className="rg-skeleton w-50" /> : c.value}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <section className="rg-actions mt-4">
          <h4 className="rg-subtitle">Quick Actions</h4>
          <div className="d-flex flex-wrap gap-2 gap-sm-3">
            <button
              className="rg-btn"
              onClick={() => navigate("/admin/cars")}
              aria-label="Manage Cars"
            >
              Add New Car
            </button>
            <button
              className="rg-btn"
              onClick={() => navigate("/admin/users")}
              aria-label="Manage Users"
            >
              View Users
            </button>
            <button
              className="rg-btn"
              onClick={() => navigate("/admin/bookings")}
              aria-label="Manage Bookings"
            >
              View Bookings
            </button>
            <button
              className="rg-btn"
              onClick={() => navigate("/admin/payments")}
              aria-label="Manage Payments"
            >
              View Payments
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Dashboard;
