import React, { useEffect, useMemo, useState } from "react";
import api from "../../api/axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Bookings.css";

const STATUS_COLORS = {
  Pending: "pending",
  Confirmed: "confirmed",
  Rejected: "rejected",
  Cancelled: "cancelled",
  Completed: "completed",
};

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const Bookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const fetchBookings = async () => {
    setLoading(true);
    setErr("");
    try {
      const response = await api.get("/admin/bookings");
      setBookings(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      setErr("Failed to load bookings");
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (bookingId, newAction) => {
    if (!newAction) return;
    try {
      if (newAction === "Approve") {
        await api.put(`/admin/bookings/${bookingId}/approve`);
      } else if (newAction === "Reject") {
        await api.put(`/admin/bookings/${bookingId}/reject`);
      }
      await fetchBookings();
    } catch (error) {
      console.error("Error updating booking status:", error);
      setErr("Failed to update booking");
    }
  };

  useEffect(() => {
    fetchBookings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return bookings.filter((b) => {
      const matchesStatus =
        statusFilter === "All" ? true : (b.status || "") === statusFilter;
      const user = b.user?.fullName || "";
      const car = `${b.car?.brand || ""} ${b.car?.model || ""}`.trim();
      const hay = `${user} ${car} ${b.id}`.toLowerCase();
      const matchesQuery = q ? hay.includes(q) : true;
      return matchesStatus && matchesQuery;
    });
  }, [bookings, query, statusFilter]);

  return (
    <div className="rg-panel container-fluid px-0">
      {/* Header Row */}
      <div className="rg-panel__head">
        <div>
          <h2 className="rg-title mb-1">Manage Bookings</h2>
          <p className="rg-sub">Approve or reject pending bookings.</p>
        </div>

        <div className="rg-tools">
          <div className="rg-input">
            <input
              type="text"
              placeholder="Search user, car, or ID…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search bookings"
            />
          </div>
          <div className="rg-select">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by status"
            >
              <option>All</option>
              <option>Pending</option>
              <option>Confirmed</option>
              <option>Rejected</option>
              <option>Cancelled</option>
              <option>Completed</option>
            </select>
          </div>
          <button
            className="rg-btn"
            onClick={fetchBookings}
            aria-label="Refresh"
          >
            Refresh
          </button>
        </div>
      </div>

      {err && (
        <div className="alert alert-danger py-2 px-3 my-2" role="alert">
          {err}
        </div>
      )}

      {/* Table */}
      <div className="rg-table-wrap">
        <table className="rg-table">
          <thead>
            <tr>
              <th>Booking ID</th>
              <th>User</th>
              <th>Car</th>
              <th>Pickup</th>
              <th>Dropoff</th>
              <th>Total</th>
              <th>Status</th>
              <th style={{ width: 180 }}>Actions</th>
            </tr>
          </thead>

          <tbody>
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={`skeleton-${i}`}>
                  <td>
                    <span className="rg-skel w-75" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                  <td>
                    <span className="rg-skel w-75" />
                  </td>
                  <td>
                    <span className="rg-skel w-75" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                </tr>
              ))
            ) : filtered.length > 0 ? (
              filtered.map((booking) => (
                <tr key={booking.id}>
                  <td className="mono">#{booking.id}</td>
                  <td>{booking.user?.fullName || "-"}</td>
                  <td>
                    {booking.car?.brand} {booking.car?.model}
                  </td>
                  <td>
                    {booking.pickupDate
                      ? new Date(booking.pickupDate).toLocaleDateString()
                      : "-"}
                  </td>
                  <td>
                    {booking.dropoffDate
                      ? new Date(booking.dropoffDate).toLocaleDateString()
                      : "-"}
                  </td>
                  <td>
                    {typeof booking.totalCost === "number"
                      ? currency.format(booking.totalCost)
                      : booking.totalCost}
                  </td>
                  <td>
                    <span
                      className={`rg-badge rg-badge--${
                        STATUS_COLORS[booking.status] || "pending"
                      }`}
                    >
                      {booking.status}
                    </span>
                  </td>
                  <td>
                    {[
                      "Cancelled",
                      "Rejected",
                      "Confirmed",
                      "Completed",
                    ].includes(booking.status) ? (
                      <span className="rg-muted">{booking.status}</span>
                    ) : (
                      <div className="rg-select rg-select--inline">
                        <select
                          aria-label="Booking action"
                          defaultValue=""
                          onChange={(e) =>
                            handleStatusChange(booking.id, e.target.value)
                          }
                        >
                          <option value="" disabled>
                            Select Action
                          </option>
                          <option value="Approve">Approve</option>
                          <option value="Reject">Reject</option>
                        </select>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8}>
                  <div className="rg-empty">
                    <div className="rg-empty__title">No bookings found</div>
                    <div className="rg-empty__sub">
                      Try clearing filters or refreshing.
                    </div>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Bookings;
