import React, { useEffect, useMemo, useState } from "react";
import api from "../../api/axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Users.css";

const Users = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // filters
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [roleFilter, setRoleFilter] = useState("All");

  const fetchUsers = async () => {
    setLoading(true);
    setErr("");
    try {
      const response = await api.get("/admin/users");
      setUsers(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error("Error fetching users:", error);
      setErr("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleBlock = async (id) => {
    try {
      await api.put(`/admin/users/${id}/block`);
      fetchUsers();
    } catch (error) {
      console.error("Error blocking/unblocking user:", error);
      setErr("Failed to update user status");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this user? This cannot be undone.")) return;
    try {
      await api.delete(`/admin/users/${id}`);
      setUsers((prev) => prev.filter((u) => u.id !== id));
    } catch (error) {
      console.error("Error deleting user:", error);
      setErr("Failed to delete user");
    }
  };

  // derive roles set (normalize to array of strings)
  const getRoles = (u) => {
    let r = u.roles ?? u.role ?? [];
    if (typeof r === "string") r = [r];
    if (!Array.isArray(r)) r = [String(r)];
    return r.filter(Boolean);
  };

  const roleOptions = useMemo(() => {
    const set = new Set();
    users.forEach((u) => getRoles(u).forEach((r) => set.add(r)));
    return ["All", ...Array.from(set)];
  }, [users]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return users.filter((u) => {
      const name =
        u.fullName ||
        [u.firstName, u.lastName].filter(Boolean).join(" ") ||
        u.firstName ||
        "";
      const email = u.email || "";
      const idStr = String(u.id || "");
      const hay = `${name} ${email} ${idStr} ${getRoles(u).join(
        " "
      )}`.toLowerCase();

      const matchesQ = q ? hay.includes(q) : true;
      const matchesStatus =
        statusFilter === "All"
          ? true
          : statusFilter === "Active"
          ? !u.isBlocked
          : !!u.isBlocked;

      const roles = getRoles(u);
      const matchesRole =
        roleFilter === "All" ? true : roles.includes(roleFilter);

      return matchesQ && matchesStatus && matchesRole;
    });
  }, [users, query, statusFilter, roleFilter]);

  return (
    <div className="rg-panel container-fluid px-0">
      {/* Head */}
      <div className="rg-panel__head">
        <div>
          <h2 className="rg-title mb-1">Manage Users</h2>
          <p className="rg-sub">
            Search, filter, block/unblock, and delete users.
          </p>
        </div>
        <div className="rg-tools">
          <div className="rg-input">
            <input
              type="text"
              placeholder="Search name, email, or ID…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search users"
            />
          </div>
          <div className="rg-select">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by status"
            >
              <option>All</option>
              <option>Active</option>
              <option>Blocked</option>
            </select>
          </div>
          <div className="rg-select">
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              aria-label="Filter by role"
            >
              {roleOptions.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </div>
          <button className="rg-btn" onClick={fetchUsers} aria-label="Refresh">
            Refresh
          </button>
        </div>
      </div>

      {err && (
        <div className="alert alert-danger py-2 px-3 my-2" role="alert">
          {err}
        </div>
      )}

      {/* Table */}
      <div className="rg-table-wrap">
        <table className="rg-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Email</th>
              <th>Roles</th>
              <th>Status</th>
              <th style={{ width: 210 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 7 }).map((_, i) => (
                <tr key={`skel-${i}`}>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                  <td>
                    <span className="rg-skel w-75" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                </tr>
              ))
            ) : filtered.length > 0 ? (
              filtered.map((u) => {
                const name =
                  u.fullName ||
                  [u.firstName, u.lastName].filter(Boolean).join(" ") ||
                  u.firstName ||
                  "—";
                const roles = getRoles(u);
                return (
                  <tr key={u.id}>
                    <td className="mono">#{u.id}</td>
                    <td className="rg-user">
                      <div className="rg-avatar">
                        {name?.[0]?.toUpperCase?.() || "U"}
                      </div>
                      <div className="rg-user__meta">
                        <div className="rg-user__name">{name}</div>
                        <div className="rg-user__sub">{u.username || ""}</div>
                      </div>
                    </td>
                    <td>{u.email || "—"}</td>
                    <td>
                      <div className="rg-chips">
                        {roles.length ? (
                          roles.map((r, idx) => (
                            <span className="rg-chip" key={`${u.id}-r-${idx}`}>
                              {r}
                            </span>
                          ))
                        ) : (
                          <span className="rg-muted">—</span>
                        )}
                      </div>
                    </td>
                    <td>
                      <span
                        className={`rg-badge ${
                          u.isBlocked ? "rg-badge--no" : "rg-badge--ok"
                        }`}
                      >
                        {u.isBlocked ? "Blocked" : "Active"}
                      </span>
                    </td>
                    <td>
                      <div className="rg-actions">
                        <button
                          className={`rg-btn rg-btn--sm ${
                            u.isBlocked ? "" : "rg-btn--warn"
                          }`}
                          onClick={() => toggleBlock(u.id)}
                        >
                          {u.isBlocked ? "Unblock" : "Block"}
                        </button>
                        <button
                          className="rg-btn rg-btn--sm rg-btn--danger"
                          onClick={() => handleDelete(u.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={6}>
                  <div className="rg-empty">
                    <div className="rg-empty__title">No users found</div>
                    <div className="rg-empty__sub">
                      Try changing filters or refresh.
                    </div>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Users;
