import React, { useEffect, useMemo, useState } from "react";
import api from "../../api/axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Cars.css";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const Cars = () => {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // Modal state
  const [showModal, setShowModal] = useState(false);
  const [editingCarId, setEditingCarId] = useState(null);
  const [formData, setFormData] = useState({
    brand: "",
    model: "",
    type: "",
    seats: 4,
    description: "",
    pricePerDay: 0,
    imageUrl: "",
    isAvailable: true,
    location: "", // NEW
  });

  // Filters/search
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("All");
  const [availFilter, setAvailFilter] = useState("All");

  const fetchCars = async () => {
    setLoading(true);
    setErr("");
    try {
      const response = await api.get("/admin/cars");
      setCars(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error("Error fetching cars:", error);
      setErr("Failed to load cars");
    } finally {
      setLoading(false);
    }
  };

  // Optional fetch by ID (preserves your old behavior via quick box)
  const fetchCarById = async (id) => {
    if (!id) return fetchCars();
    setLoading(true);
    setErr("");
    try {
      const response = await api.get(`/admin/cars/${id}`);
      setCars(response.data ? [response.data] : []);
    } catch (error) {
      console.error("Error fetching car by ID:", error);
      setErr("Car not found");
      setCars([]);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () =>
    setFormData({
      brand: "",
      model: "",
      type: "",
      seats: 4,
      description: "",
      pricePerDay: 0,
      imageUrl: "",
      isAvailable: true,
      location: "", // NEW
    });

  // Add/Edit
  const handleAddEditCar = async () => {
    try {
      const payload = {
        ...formData,
        seats: Number(formData.seats) || 0,
        pricePerDay: Number(formData.pricePerDay) || 0,
        location: formData.location, // NEW
      };
      if (editingCarId) {
        await api.put(`/admin/cars/${editingCarId}`, payload);
      } else {
        await api.post("/admin/cars", payload);
      }
      setShowModal(false);
      setEditingCarId(null);
      resetForm();
      fetchCars();
    } catch (error) {
      console.error("Error saving car:", error);
      setErr("Failed to save car");
    }
  };

  // Delete
  const handleDeleteCar = async (id) => {
    if (!window.confirm("Delete this car?")) return;
    try {
      await api.delete(`/admin/cars/${id}`);
      fetchCars();
    } catch (error) {
      console.error("Error deleting car:", error);
      setErr("Failed to delete car");
    }
  };

  // Edit button
  const handleEditClick = (car) => {
    setEditingCarId(car.id);
    setFormData({
      brand: car.brand || "",
      model: car.model || "",
      type: car.type || "",
      seats: car.seats ?? 4,
      description: car.description || "",
      pricePerDay: car.pricePerDay ?? 0,
      imageUrl: car.imageUrl || "",
      isAvailable: !!car.isAvailable,
      location: car.location || car.city || car.pickupCity || "", // NEW
    });
    setShowModal(true);
  };

  useEffect(() => {
    fetchCars();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Derived filters
  const typeOptions = useMemo(() => {
    const set = new Set(cars.map((c) => (c.type || "").trim()).filter(Boolean));
    return ["All", ...Array.from(set)];
  }, [cars]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return cars.filter((c) => {
      const matchesQ = q
        ? `${c.id} ${c.brand} ${c.model} ${c.type} ${
            c.location || c.city || c.pickupCity || ""
          }`
            .toLowerCase()
            .includes(q)
        : true;
      const matchesType =
        typeFilter === "All" ? true : (c.type || "") === typeFilter;
      const matchesAvail =
        availFilter === "All"
          ? true
          : availFilter === "Available"
          ? !!c.isAvailable
          : !c.isAvailable;
      return matchesQ && matchesType && matchesAvail;
    });
  }, [cars, search, typeFilter, availFilter]);

  // Location options for the modal
  const locationOptions = ["Chennai", "Madurai", "Coimbatore"];

  return (
    <div className="rg-panel container-fluid px-0">
      {/* Header */}
      <div className="rg-panel__head">
        <div>
          <h2 className="rg-title mb-1">Manage Cars</h2>
          <p className="rg-sub">
            Add, edit, filter, and remove cars from the fleet.
          </p>
        </div>

        <div className="rg-tools">
          <div className="rg-input">
            <input
              type="text"
              placeholder="Search brand, model, type, location, or ID…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search cars"
            />
          </div>

          <div className="rg-select">
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              aria-label="Filter by type"
            >
              {typeOptions.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div className="rg-select">
            <select
              value={availFilter}
              onChange={(e) => setAvailFilter(e.target.value)}
              aria-label="Filter by availability"
            >
              <option>All</option>
              <option>Available</option>
              <option>Unavailable</option>
            </select>
          </div>

          <button
            className="rg-btn"
            onClick={() => fetchCars()}
            aria-label="Refresh"
          >
            Refresh
          </button>

          <button
            className="rg-btn rg-btn--ghost"
            onClick={() => {
              setEditingCarId(null);
              resetForm();
              setShowModal(true);
            }}
            aria-label="Add new car"
          >
            + Add Car
          </button>
        </div>
      </div>

      {err && (
        <div className="alert alert-danger py-2 px-3 my-2" role="alert">
          {err}
        </div>
      )}

      {/* Optional quick search by ID (keeps your old UX) */}
      <div className="rg-quick mb-2">
        <div className="rg-input">
          <input
            type="text"
            placeholder="Quick search by exact ID…"
            onKeyDown={(e) => {
              if (e.key === "Enter") fetchCarById(e.currentTarget.value);
            }}
            aria-label="Search by ID"
          />
        </div>
        <button
          className="rg-btn"
          onClick={() => {
            const el = document.querySelector(".rg-quick input");
            fetchCarById(el?.value || "");
          }}
        >
          Go
        </button>
      </div>

      {/* Table */}
      <div className="rg-table-wrap">
        <table className="rg-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Vehicle</th>
              <th>Type</th>
              <th>Seats</th>
              <th>Price / Day</th>
              <th>Available</th>
              <th style={{ width: 180 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={`s-${i}`}>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                  <td>
                    <span className="rg-skel w-75" />
                  </td>
                  <td>
                    <span className="rg-skel w-25" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                </tr>
              ))
            ) : filtered.length > 0 ? (
              filtered.map((car) => (
                <tr key={car.id}>
                  <td className="mono">#{car.id}</td>
                  <td className="rg-vehicle">
                    <div className="rg-thumb">
                      {car.imageUrl ? (
                        <img
                          src={car.imageUrl}
                          alt={`${car.brand} ${car.model}`}
                        />
                      ) : (
                        <div className="rg-thumb__ph">🚗</div>
                      )}
                    </div>
                    <div className="rg-vehicle__meta">
                      <div className="rg-vehicle__title">
                        {car.brand} {car.model}
                      </div>
                      <div className="rg-vehicle__sub">
                        {car.description || "—"}
                        {/* Show location inline if present */}
                        {(car.location || car.city || car.pickupCity) && (
                          <span className="ms-2">
                            • {car.location || car.city || car.pickupCity}
                          </span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td>{car.type || "—"}</td>
                  <td>{car.seats ?? "—"}</td>
                  <td>
                    {typeof car.pricePerDay === "number"
                      ? currency.format(car.pricePerDay)
                      : car.pricePerDay}
                  </td>
                  <td>
                    <span
                      className={`rg-badge ${
                        car.isAvailable ? "rg-badge--ok" : "rg-badge--no"
                      }`}
                    >
                      {car.isAvailable ? "Available" : "Unavailable"}
                    </span>
                  </td>
                  <td>
                    <div className="rg-actions">
                      <button
                        className="rg-btn rg-btn--sm rg-btn--ghost"
                        onClick={() => handleEditClick(car)}
                      >
                        Edit
                      </button>
                      <button
                        className="rg-btn rg-btn--sm rg-btn--danger"
                        onClick={() => handleDeleteCar(car.id)}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7}>
                  <div className="rg-empty">
                    <div className="rg-empty__title">No cars found</div>
                    <div className="rg-empty__sub">
                      Try adjusting filters or add a new car.
                    </div>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      <div
        className={`modal fade ${showModal ? "show d-block" : ""}`}
        tabIndex="-1"
        role="dialog"
      >
        <div
          className="modal-dialog modal-lg modal-dialog-centered"
          role="document"
        >
          <div className="modal-content rg-modal">
            <div className="modal-header">
              <h5 className="modal-title">
                {editingCarId ? "Edit Car" : "Add Car"}
              </h5>
              <button
                type="button"
                className="btn-close"
                onClick={() => setShowModal(false)}
                aria-label="Close"
              />
            </div>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Brand</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.brand}
                    onChange={(e) =>
                      setFormData({ ...formData, brand: e.target.value })
                    }
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Model</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.model}
                    onChange={(e) =>
                      setFormData({ ...formData, model: e.target.value })
                    }
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Type</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.type}
                    onChange={(e) =>
                      setFormData({ ...formData, type: e.target.value })
                    }
                  />
                </div>

                {/* NEW: Location select */}
                <div className="col-md-6">
                  <label className="form-label">Location</label>
                  <select
                    className="form-select"
                    value={formData.location}
                    onChange={(e) =>
                      setFormData({ ...formData, location: e.target.value })
                    }
                  >
                    <option value="">Select Location</option>
                    {locationOptions.map((loc) => (
                      <option key={loc} value={loc}>
                        {loc}
                      </option>
                    ))}
                    {/* If editing a car with a custom city, still show it */}
                    {formData.location &&
                      !locationOptions.includes(formData.location) && (
                        <option value={formData.location}>
                          {formData.location}
                        </option>
                      )}
                  </select>
                </div>

                <div className="col-md-3">
                  <label className="form-label">Seats</label>
                  <input
                    type="number"
                    className="form-control"
                    value={formData.seats}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        seats: Number(e.target.value),
                      })
                    }
                  />
                </div>
                <div className="col-md-3">
                  <label className="form-label">Price / Day</label>
                  <input
                    type="number"
                    className="form-control"
                    value={formData.pricePerDay}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        pricePerDay: Number(e.target.value),
                      })
                    }
                  />
                </div>
                <div className="col-12">
                  <label className="form-label">Description</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                  />
                </div>
                <div className="col-12">
                  <label className="form-label">Image URL</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.imageUrl}
                    onChange={(e) =>
                      setFormData({ ...formData, imageUrl: e.target.value })
                    }
                  />
                  <div className="rg-preview mt-2">
                    {formData.imageUrl ? (
                      // eslint-disable-next-line jsx-a11y/img-redundant-alt
                      <img src={formData.imageUrl} alt="Car preview image" />
                    ) : (
                      <div className="rg-thumb__ph">🚗</div>
                    )}
                  </div>
                </div>

                {editingCarId && (
                  <div className="col-12">
                    <label className="form-check">
                      <input
                        type="checkbox"
                        className="form-check-input me-2"
                        checked={formData.isAvailable}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            isAvailable: e.target.checked,
                          })
                        }
                      />
                      <span className="form-check-label">Available</span>
                    </label>
                  </div>
                )}
              </div>
            </div>
            <div className="modal-footer">
              <button
                className="rg-btn rg-btn--ghost"
                onClick={() => setShowModal(false)}
              >
                Cancel
              </button>
              <button className="rg-btn" onClick={handleAddEditCar}>
                {editingCarId ? "Update" : "Add"}
              </button>
            </div>
          </div>
        </div>
      </div>
      {showModal && (
        <div
          className="modal-backdrop fade show"
          onClick={() => setShowModal(false)}
        />
      )}
    </div>
  );
};

export default Cars;
