import React, { useEffect, useMemo, useState } from "react";
import api from "../../api/axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Payments.css";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const Payments = () => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [methodFilter, setMethodFilter] = useState("All");

  const fetchPayments = async () => {
    setLoading(true);
    setErr("");
    try {
      const res = await api.get("/admin/payments");
      setPayments(Array.isArray(res.data) ? res.data : []);
    } catch (e) {
      console.error("Error fetching payments:", e);
      setErr("Failed to load payments");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const approvePayment = async (id) => {
    try {
      await api.put(`/admin/payments/${id}/approve`);
      fetchPayments();
    } catch (e) {
      console.error("Error approving payment:", e);
      setErr("Failed to approve payment");
    }
  };

  const rejectPayment = async (id) => {
    try {
      await api.put(`/admin/payments/${id}/reject`);
      fetchPayments();
    } catch (e) {
      console.error("Error rejecting payment:", e);
      setErr("Failed to reject payment");
    }
  };

  const methods = useMemo(() => {
    const set = new Set(payments.map((p) => p.paymentMethod).filter(Boolean));
    return ["All", ...Array.from(set)];
  }, [payments]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return payments.filter((p) => {
      const hay =
        `${p.id} ${p.userEmail} ${p.car} ${p.bookingId}`.toLowerCase();
      const matchesQ = q ? hay.includes(q) : true;
      const matchesStatus =
        statusFilter === "All" ? true : p.status === statusFilter;
      const matchesMethod =
        methodFilter === "All" ? true : p.paymentMethod === methodFilter;
      return matchesQ && matchesStatus && matchesMethod;
    });
  }, [payments, query, statusFilter, methodFilter]);

  return (
    <div className="rg-panel container-fluid px-0">
      {/* Head */}
      <div className="rg-panel__head">
        <div>
          <h2 className="rg-title mb-1">Manage Payments</h2>
          <p className="rg-sub">Approve pending payments and audit history.</p>
        </div>
        <div className="rg-tools">
          <div className="rg-input">
            <input
              type="text"
              placeholder="Search email, car, or ID…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search payments"
            />
          </div>
          <div className="rg-select">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by status"
            >
              <option>All</option>
              <option>Pending</option>
              <option>Approved</option>
              <option>Rejected</option>
            </select>
          </div>
          <div className="rg-select">
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
              aria-label="Filter by method"
            >
              {methods.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
          </div>
          <button className="rg-btn" onClick={fetchPayments}>
            Refresh
          </button>
        </div>
      </div>

      {err && (
        <div className="alert alert-danger py-2 px-3 my-2" role="alert">
          {err}
        </div>
      )}

      {/* Table */}
      <div className="rg-table-wrap">
        <table className="rg-table">
          <thead>
            <tr>
              <th>Payment ID</th>
              <th>User Email</th>
              <th>Car</th>
              <th>Amount</th>
              <th>Method</th>
              <th>Status</th>
              <th>Booking ID</th>
              <th style={{ width: 200 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={`skel-${i}`}>
                  <td>
                    <span className="rg-skel w-75" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                </tr>
              ))
            ) : filtered.length > 0 ? (
              filtered.map((p) => (
                <tr key={p.id}>
                  <td className="mono">#{p.id}</td>
                  <td>{p.userEmail}</td>
                  <td>{p.car}</td>
                  <td>
                    {typeof p.amount === "number"
                      ? currency.format(p.amount)
                      : p.amount}
                  </td>
                  <td>{p.paymentMethod}</td>
                  <td>
                    <span
                      className={`rg-badge ${
                        p.status === "Approved"
                          ? "rg-badge--ok"
                          : p.status === "Rejected"
                          ? "rg-badge--no"
                          : "rg-badge--pending"
                      }`}
                    >
                      {p.status}
                    </span>
                  </td>
                  <td>{p.bookingId}</td>
                  <td>
                    {p.status === "Pending" ? (
                      <div className="rg-actions">
                        <button
                          className="rg-btn rg-btn--sm"
                          onClick={() => approvePayment(p.id)}
                        >
                          Approve
                        </button>
                        <button
                          className="rg-btn rg-btn--sm rg-btn--danger"
                          onClick={() => rejectPayment(p.id)}
                        >
                          Reject
                        </button>
                      </div>
                    ) : (
                      <span className="rg-muted">No actions</span>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8}>
                  <div className="rg-empty">
                    <div className="rg-empty__title">No payments found</div>
                    <div className="rg-empty__sub">
                      Try changing filters or refreshing.
                    </div>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Payments;
