import React, { useEffect, useState, useMemo } from "react";
import api from "../../api/axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Documents.css";

const Documents = () => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  // Fetch all users with documents
  const fetchDocuments = async () => {
    setLoading(true);
    setErr("");
    try {
      const response = await api.get("/admin/documents");
      setDocuments(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error("Error fetching documents", error);
      setErr("Failed to load documents");
    } finally {
      setLoading(false);
    }
  };

  // Get document image blob
  const fetchDocumentImage = async (userId, type) => {
    try {
      const response = await api.get(`/admin/documents/${userId}/${type}`, {
        responseType: "blob",
      });
      const file = new Blob([response.data], {
        type: response.headers["content-type"] || "application/octet-stream",
      });
      return URL.createObjectURL(file);
    } catch (error) {
      console.error(`Error fetching ${type} for user ${userId}`, error);
      return null;
    }
  };

  const handleViewDoc = async (userId, type) => {
    const fileUrl = await fetchDocumentImage(userId, type);
    if (fileUrl) window.open(fileUrl, "_blank");
  };

  // Approve / Reject
  const handleApprove = async (id) => {
    try {
      await api.put(`/admin/documents/${id}/approve`);
      fetchDocuments();
    } catch (error) {
      console.error("Error approving document:", error);
    }
  };

  const handleReject = async (id) => {
    try {
      await api.put(`/admin/documents/${id}/reject`);
      fetchDocuments();
    } catch (error) {
      console.error("Error rejecting document:", error);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return documents.filter((d) => {
      const hay = `${d.userId} ${d.status}`.toLowerCase();
      const matchesQ = q ? hay.includes(q) : true;
      const matchesStatus =
        statusFilter === "All" ? true : d.status === statusFilter;
      return matchesQ && matchesStatus;
    });
  }, [documents, query, statusFilter]);

  return (
    <div className="rg-panel container-fluid px-0">
      {/* Head */}
      <div className="rg-panel__head">
        <div>
          <h2 className="rg-title mb-1">Manage Documents</h2>
          <p className="rg-sub">Verify Aadhar and License submissions.</p>
        </div>
        <div className="rg-tools">
          <div className="rg-input">
            <input
              type="text"
              placeholder="Search by user ID…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div className="rg-select">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option>All</option>
              <option>Pending</option>
              <option>Approved</option>
              <option>Rejected</option>
            </select>
          </div>
          <button className="rg-btn" onClick={fetchDocuments}>
            Refresh
          </button>
        </div>
      </div>

      {err && (
        <div className="alert alert-danger py-2 px-3 my-2" role="alert">
          {err}
        </div>
      )}

      {/* Table */}
      <div className="rg-table-wrap">
        <table className="rg-table">
          <thead>
            <tr>
              <th>User ID</th>
              <th>Aadhar</th>
              <th>License</th>
              <th>Status</th>
              <th style={{ width: 200 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={`skel-${i}`}>
                  <td>
                    <span className="rg-skel w-75" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-50" />
                  </td>
                  <td>
                    <span className="rg-skel w-100" />
                  </td>
                </tr>
              ))
            ) : filtered.length > 0 ? (
              filtered.map((doc) => (
                <tr key={doc.id}>
                  <td className="mono">#{doc.userId}</td>
                  <td>
                    <button
                      className="rg-btn rg-btn--sm"
                      onClick={() => handleViewDoc(doc.userId, "aadhar")}
                    >
                      View
                    </button>
                  </td>
                  <td>
                    <button
                      className="rg-btn rg-btn--sm"
                      onClick={() => handleViewDoc(doc.userId, "license")}
                    >
                      View
                    </button>
                  </td>
                  <td>
                    <span
                      className={`rg-badge ${
                        doc.status === "Approved"
                          ? "rg-badge--ok"
                          : doc.status === "Rejected"
                          ? "rg-badge--no"
                          : "rg-badge--pending"
                      }`}
                    >
                      {doc.status}
                    </span>
                  </td>
                  <td>
                    {doc.status === "Pending" ? (
                      <div className="rg-actions">
                        <button
                          className="rg-btn rg-btn--sm"
                          onClick={() => handleApprove(doc.id)}
                        >
                          Approve
                        </button>
                        <button
                          className="rg-btn rg-btn--sm rg-btn--danger"
                          onClick={() => handleReject(doc.id)}
                        >
                          Reject
                        </button>
                      </div>
                    ) : (
                      <span className="rg-muted">No Action</span>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5}>
                  <div className="rg-empty">
                    <div className="rg-empty__title">No documents found</div>
                    <div className="rg-empty__sub">
                      Try changing filters or refreshing.
                    </div>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Documents;
