import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginAsAdminCompatible } from "../../services/adminAuth";
import "bootstrap/dist/css/bootstrap.min.css";

const AgentLogin = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      const token = await loginAsAdminCompatible(form);
      localStorage.setItem("adminToken", token); // same key used by Admin
      navigate("/agent/dashboard", { replace: true });
    } catch (error) {
      console.error("Agent login error:", error);
      setErr(error.message || "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="container d-flex align-items-center justify-content-center"
      style={{ minHeight: "100vh" }}
    >
      <form
        className="rg-card p-4"
        onSubmit={onSubmit}
        style={{ maxWidth: 420, width: "100%" }}
      >
        <h4 className="mb-3">Rental Agent Login</h4>
        {err && <div className="alert alert-danger py-2">{err}</div>}

        <div className="mb-3">
          <label className="form-label">Email / Username</label>
          <input
            className="form-control"
            name="email"
            type="text"
            value={form.email}
            onChange={onChange}
            required
            autoFocus
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            className="form-control"
            name="password"
            type="password"
            value={form.password}
            onChange={onChange}
            required
          />
        </div>

        <button
          className="btn btn-primary w-100"
          type="submit"
          disabled={loading}
        >
          {loading ? "Signing in..." : "Sign in"}
        </button>
      </form>
    </div>
  );
};

export default AgentLogin;
