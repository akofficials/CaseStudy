import React from "react";

const AgentDashboard = () => {
  return (
    <div className="container py-3">
      <div className="rg-card p-3">
        <h4 className="mb-1">Welcome, Rental Agent 👋</h4>
        <div className="text-muted">
          Use the sidebar to manage Cars, Bookings, and Documents.
        </div>
      </div>
    </div>
  );
};

export default AgentDashboard;
