import React from 'react';

const AdminRegister = () => {
  return (
    <div className="container mt-5">
      <h2>Admin Registration</h2>
      {/* Add form here later */}
    </div>
  );
};

export default AdminRegister;
