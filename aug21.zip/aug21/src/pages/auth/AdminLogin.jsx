import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../../api/axios";
import "animate.css";
import "./Auth.css"; // new CSS file for styling

const AdminLogin = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await api.post("/auth/login", formData);

      if (res.data.role !== "Admin") {
        setError("Access denied: Not an Admin.");
        return;
      }

      // store both (keeps Admin area consistent with your logout)
      localStorage.setItem("adminToken", res.data.token);
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("role", res.data.role);
      localStorage.setItem("email", res.data.email);

      // go straight to Manage Users
      navigate("/admin/users", { replace: true });
    } catch (err) {
      setError(err.response?.data || "Login failed");
    }
  };

  return (
    <div className="auth-bg d-flex justify-content-center align-items-center min-vh-100">
      <div className="auth-card shadow-lg p-5 animate__animated animate__fadeInDown">
        <h3 className="text-center mb-4 text-danger"> SpeedUp Admin Login</h3>
        {error && (
          <div className="alert alert-danger animate__animated animate__shakeX">
            {error}
          </div>
        )}
        <form
          onSubmit={handleSubmit}
          className="animate__animated animate__fadeInUp"
        >
          <div className="form-group mb-3">
            <input
              name="email"
              type="email"
              className="form-control form-control-lg"
              placeholder="Email"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group mb-4">
            <input
              name="password"
              type="password"
              className="form-control form-control-lg"
              placeholder="Password"
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-dark w-100 custom-btn">
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
