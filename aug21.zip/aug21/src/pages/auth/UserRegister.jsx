import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../api/axios';
import 'animate.css';
import './Auth.css'; // new CSS file

const UserRegister = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    password: '',
    role: 'User',
  });

  const [error, setError] = useState('');

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    try {
      await api.post('/auth/register', formData);
      alert('🎉 Registration successful! Please login.');
      navigate('/user/login');
    } catch (err) {
      setError(err.response?.data || 'Registration failed');
    }
  };

  return (
    <div className="auth-bg d-flex justify-content-center align-items-center min-vh-100">
      <div className="auth-card shadow-lg p-5 animate__animated animate__fadeInUp">
        <h3 className="text-center mb-4 text-danger">Create Account</h3>
        {error && <div className="alert alert-danger animate__animated animate__shakeX">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <input type="text" name="firstName" className="form-control form-control-lg" placeholder="First Name" onChange={handleChange} required />
          </div>
          <div className="mb-3">
            <input type="text" name="lastName" className="form-control form-control-lg" placeholder="Last Name" onChange={handleChange} required />
          </div>
          <div className="mb-3">
            <input type="email" name="email" className="form-control form-control-lg" placeholder="Email" onChange={handleChange} required />
          </div>
          <div className="mb-3">
            <input type="text" name="phoneNumber" className="form-control form-control-lg" placeholder="Phone Number" onChange={handleChange} required />
          </div>
          <div className="mb-4">
            <input type="password" name="password" className="form-control form-control-lg" placeholder="Password" onChange={handleChange} required />
          </div>
          <button className="btn btn-dark w-100 custom-btn">Register</button>
        </form>
        <p className="text-center mt-3 text-white">
          Already have an account? <a href="/user/login" className="link-danger">Login</a>
        </p>
      </div>
    </div>
  );
};

export default UserRegister;
