// src/pages/Payment.jsx
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { jwtDecode } from "jwt-decode";
import "bootstrap/dist/css/bootstrap.min.css";

const Payment = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { bookingId, carName, pickupDate, dropoffDate, totalPrice } =
    location.state || {};

  const [paymentMethod, setPaymentMethod] = useState("");
  const [upiId, setUpiId] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [paypalEmail, setPaypalEmail] = useState("");

  const token = localStorage.getItem("token");
  let userId = null;
  if (token) {
    try {
      const decoded = jwtDecode(token);
      userId = decoded.UserId;
    } catch (err) {
      console.error("Invalid token", err);
    }
  }

  // ❌ If any key info is missing → block payment
  if (!bookingId || !pickupDate || !dropoffDate || !totalPrice) {
    return (
      <div className="container text-center mt-5">
        <h4 className="text-danger">
          Invalid payment session. Go back to Cars page.
        </h4>
        <button className="btn btn-dark mt-3" onClick={() => navigate("/cars")}>
          Back to Cars
        </button>
      </div>
    );
  }

  // ✅ Handle payment
  const handlePayment = async () => {
    try {
      if (!paymentMethod) {
        alert("Please select a payment method.");
        return;
      }

      const payload = {
        bookingId, // ✅ Correct booking reference
        amount: totalPrice,
        paymentMethod,
        upiId: paymentMethod === "UPI" ? upiId : null,
        cardNumber: paymentMethod === "Card" ? cardNumber : null,
        expiryDate: paymentMethod === "Card" ? cardExpiry : null,
        cvv: paymentMethod === "Card" ? cardCvv : null,
        payPalEmail: paymentMethod === "PayPal" ? paypalEmail : null,
        status: "Pending",
      };

      const res = await api.post("/user/payments", payload, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (res.data) {
        alert(
          "✅ Payment request submitted successfully. Awaiting admin approval."
        );
        navigate("/booking-history");
      }
    } catch (err) {
      console.error("Payment error", err.response?.data || err.message);
      alert(err.response?.data || "❌ Failed to process payment.");
    }
  };

  // ✅ Header Section
  const Header = () => (
    <header className="bg-dark text-white py-3 px-5 d-flex justify-content-between align-items-center">
      <h3 className="m-0">SpeedUp</h3>
      <div>
        <button
          className="btn btn-outline-light me-2"
          onClick={() => navigate("/")}
        >
          Home
        </button>
        <button
          className="btn btn-outline-light me-2"
          onClick={() => navigate("/user/profile")}
        >
          Profile
        </button>
        <button
          className="btn btn-danger"
          onClick={() => {
            localStorage.removeItem("token");
            navigate("/user/login");
          }}
        >
          Logout
        </button>
      </div>
    </header>
  );

  // ✅ Footer Section
  const Footer = () => (
    <footer className="bg-dark text-white py-3 mt-5">
      <div className="container text-center">
        <p className="mb-0">© 2025 SpeedUp. All rights reserved.</p>
      </div>
    </footer>
  );

  return (
    <div style={{ backgroundColor: "#f8f9fa", minHeight: "100vh" }}>
      <Header />
      <div className="container mt-5">
        <center>
          <h2 className="section-heading text-dark">Payment & Booking</h2>
        </center>
        <div className="card shadow p-4">
          <h4>
            <b>{carName}</b>
          </h4>
          <p>
            <b>Pickup:</b> {pickupDate} <br />
            <b>Dropoff:</b> {dropoffDate}
          </p>
          <h5 className="text-dark">Total Price: ₹{totalPrice}</h5>

          {/* Payment Method */}
          <div className="form-group mt-3">
            <label>Select Payment Method</label>
            <select
              className="form-control"
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
            >
              <option value="">-- Select --</option>
              <option value="UPI">UPI</option>
              <option value="Card">Card</option>
              <option value="PayPal">PayPal</option>
            </select>
          </div>

          {/* UPI */}
          {paymentMethod === "UPI" && (
            <div className="form-group mt-3">
              <label>UPI ID</label>
              <input
                type="text"
                className="form-control"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="example@upi"
              />
            </div>
          )}

          {/* Card */}
          {paymentMethod === "Card" && (
            <>
              <div className="form-group mt-3">
                <label>Card Number</label>
                <input
                  type="text"
                  className="form-control"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  placeholder="1234567812345678"
                  maxLength="16"
                />
              </div>
              <div className="form-group mt-3">
                <label>Expiry Date</label>
                <input
                  type="text"
                  className="form-control"
                  value={cardExpiry}
                  onChange={(e) => {
                    let val = e.target.value.replace(/\D/g, "");
                    if (val.length > 6) val = val.slice(0, 6);
                    if (val.length >= 3) {
                      val = val.slice(0, 2) + "/" + val.slice(2);
                    }
                    setCardExpiry(val);
                  }}
                  placeholder="MM/YYYY"
                  maxLength="7"
                />
              </div>
              <div className="form-group mt-3">
                <label>CVV</label>
                <input
                  type="password"
                  className="form-control"
                  value={cardCvv}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (/^\d{0,3}$/.test(val)) {
                      setCardCvv(val);
                    }
                  }}
                  placeholder="***"
                  maxLength="3"
                />
              </div>
            </>
          )}

          {/* PayPal */}
          {paymentMethod === "PayPal" && (
            <div className="form-group mt-3">
              <label>PayPal Email</label>
              <input
                type="email"
                className="form-control"
                value={paypalEmail}
                onChange={(e) => setPaypalEmail(e.target.value)}
                placeholder="your@email.com"
              />
            </div>
          )}

          <button className="btn btn-danger mt-4 w-100" onClick={handlePayment}>
            Submit Payment
          </button>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Payment;
