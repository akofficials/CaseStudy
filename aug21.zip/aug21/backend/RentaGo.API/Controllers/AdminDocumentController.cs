﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/admin/documents")]
    [Authorize(Roles = "Admin")]
    public class AdminDocumentController : ControllerBase
    {
        private readonly IAdminDocumentRepository _repository;

        public AdminDocumentController(IAdminDocumentRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllDocuments()
        {
            var result = await _repository.GetAllDocumentsAsync();

            foreach (var doc in result)
            {
                var baseUrl = $"{Request.Scheme}://{Request.Host}/api/admin/documents/{doc.Id}/";
                if (doc.AadharUrl != null) doc.AadharUrl = baseUrl + "aadhar";
                if (doc.LicenseUrl != null) doc.LicenseUrl = baseUrl + "license";
                if (doc.InsuranceUrl != null) doc.InsuranceUrl = baseUrl + "insurance";
            }

            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetDocumentById(int id)
        {
            var doc = await _repository.GetDocumentByIdAsync(id);
            if (doc == null) return NotFound("Document not found.");

            return Ok(doc);
        }

        [HttpGet("status/{status}")]
        public async Task<IActionResult> GetDocumentsByStatus(string status)
        {
            var validStatuses = new[] { "Pending", "Approved", "Rejected" };

            if (!validStatuses.Contains(status, StringComparer.OrdinalIgnoreCase))
                return BadRequest("Invalid status value.");

            var docs = await _repository.GetDocumentsByStatusAsync(status);
            return Ok(docs);
        }

        [HttpGet("{id}/aadhar")]
        public async Task<IActionResult> GetAadharImage(int id)
        {
            var image = await _repository.GetImageAsync(id, "aadhar");
            return image == null ? NotFound("Aadhar image not found.") : File(image, "image/jpeg");
        }

        [HttpGet("{id}/license")]
        public async Task<IActionResult> GetLicenseImage(int id)
        {
            var image = await _repository.GetImageAsync(id, "license");
            return image == null ? NotFound("License image not found.") : File(image, "image/jpeg");
        }

        [HttpGet("{id}/insurance")]
        public async Task<IActionResult> GetInsuranceImage(int id)
        {
            var image = await _repository.GetImageAsync(id, "insurance");
            return image == null ? NotFound("Insurance image not found.") : File(image, "image/jpeg");
        }

        [HttpPut("{id}/approve")]
        public async Task<IActionResult> ApproveDocument(int id)
        {
            var success = await _repository.ApproveDocumentAsync(id);
            return success ? Ok(new { message = "Document approved successfully." }) : NotFound("Document not found.");
        }

        [HttpPut("{id}/reject")]
        public async Task<IActionResult> RejectDocument(int id)
        {
            var success = await _repository.RejectDocumentAsync(id);
            return success ? Ok(new { message = "Document rejected." }) : NotFound("Document not found.");
        }
    }
}
