﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/admin/reviews")]
    [Authorize(Roles = "Admin")]
    public class AdminReviewController : ControllerBase
    {
        private readonly IAdminReviewRepository _repository;

        public AdminReviewController(IAdminReviewRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllReviews()
        {
            var reviews = await _repository.GetAllReviewsAsync();
            return Ok(reviews);
        }
    }
}
