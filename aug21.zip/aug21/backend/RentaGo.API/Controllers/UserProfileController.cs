﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.DTOs.User;
using RentaGo.Repositories.Interfaces;
using System.Security.Claims;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/user/profile")]
    [Authorize(Roles = "User")]
    public class UserProfileController : ControllerBase
    {
        private readonly IUserRepository _userRepository;

        public UserProfileController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetProfile()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.Name)!);
            var profile = await _userRepository.GetUserProfileAsync(userId);
            if (profile == null)
                return NotFound("User not found.");

            return Ok(profile);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProfile([FromBody] UserProfileUpdateDto updateDto)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.Name)!);
            var result = await _userRepository.UpdateUserProfileAsync(userId, updateDto);
            if (result == "User not found.")
                return NotFound(result);

            return Ok(result);
        }
    }
}
