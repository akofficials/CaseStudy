﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.DTOs;
using RentaGo.Repositories.Interfaces;
using System.Security.Claims;

namespace RentaGo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly IBookingRepository _bookingRepo;

        public BookingController(IBookingRepository bookingRepo)
        {
            _bookingRepo = bookingRepo;
        }

        [HttpPost]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> CreateBooking(BookingRequest request)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.Name)!.Value);
            var (success, message, bookingId, amount) = await _bookingRepo.CreateBookingAsync(request, userId);

            if (!success)
                return BadRequest(new { message }); // <-- important

            return Ok(new { message, bookingId, amount });
        }

        [HttpGet("me")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> GetMyBookings()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.Name)?.Value!);
            var bookings = await _bookingRepo.GetUserBookingsAsync(userId);
            return Ok(bookings);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllBookings()
        {
            var bookings = await _bookingRepo.GetAllBookingsAsync();
            return Ok(bookings);
        }

        [HttpPut("cancel/{id}")]
        [Authorize]
        public async Task<IActionResult> CancelBooking(int id)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.Name)?.Value!);
            var role = User.FindFirst(ClaimTypes.Role)?.Value!;

            var success = await _bookingRepo.CancelBookingAsync(id, userId, role);
            if (!success)
                return BadRequest("Unable to cancel booking.");

            return Ok("Booking has been cancelled.");
        }
    }
}
