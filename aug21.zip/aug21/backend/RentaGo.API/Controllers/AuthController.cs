﻿using Microsoft.AspNetCore.Mvc;
using RentaGo.DTOs;
using RentaGo.Models.DTOs;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepository _repository;

        public AuthController(IAuthRepository repository)
        {
            _repository = repository;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest request)
        {
            var error = await _repository.RegisterAsync(request);
            if (error != null)
                return BadRequest(error);

            return Ok("User registered successfully.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            var (token, email, role, error) = await _repository.LoginAsync(request);
            if (error != null)
                return Unauthorized(error);

            return Ok(new
            {
                token,
                email,
                role
            });
        }
    }
}
