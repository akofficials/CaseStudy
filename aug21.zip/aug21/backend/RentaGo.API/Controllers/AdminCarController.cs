﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.DTOs.Car;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/admin/cars")]
    [Authorize(Roles = "Admin")]
    public class AdminCarController : ControllerBase
    {
        private readonly IAdminCarRepository _carRepository;

        public AdminCarController(IAdminCarRepository carRepository)
        {
            _carRepository = carRepository;
        }

        // GET: api/admin/cars
        [HttpGet]
        public async Task<IActionResult> GetAllCars()
        {
            var cars = await _carRepository.GetAllCarsAsync();
            return Ok(cars);
        }

        // GET: api/admin/cars/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCarById(int id)
        {
            var car = await _carRepository.GetCarByIdAsync(id);
            if (car == null)
                return NotFound("Car not found.");

            return Ok(car);
        }

        // POST: api/admin/cars
        [HttpPost]
        public async Task<IActionResult> AddCar([FromBody] AddCarRequest request)
        {
            var car = await _carRepository.AddCarAsync(request);
            return Ok(new { message = "Car added successfully", carId = car.Id });
        }

        // PUT: api/admin/cars/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCar(int id, [FromBody] UpdateCarRequest request)
        {
            var updated = await _carRepository.UpdateCarAsync(id, request);
            if (!updated)
                return NotFound("Car not found.");

            return Ok(new { message = "Car updated successfully." });
        }

        // DELETE: api/admin/cars/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCar(int id)
        {
            var deleted = await _carRepository.SoftDeleteCarAsync(id);
            if (!deleted)
                return NotFound("Car not found.");

            return Ok(new { message = "Car deleted (soft delete) successfully" });
        }
    }
}
