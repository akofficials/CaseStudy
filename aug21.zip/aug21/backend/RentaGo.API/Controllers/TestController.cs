﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        // Public - no login required
        [HttpGet("public")]
        public IActionResult PublicEndpoint()
        {
            return Ok("Anyone can access this.");
        }

        // Protected - requires valid JWT token
        [Authorize]
        [HttpGet("protected")]
        public IActionResult ProtectedEndpoint()
        {
            return Ok("You are authenticated and allowed to access this.");
        }
    }
}
