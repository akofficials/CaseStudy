﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/admin/users")]
    [Authorize(Roles = "Admin")]
    public class AdminUserController : ControllerBase
    {
        private readonly IAdminUserRepository _repository;

        public AdminUserController(IAdminUserRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await _repository.GetAllUsersAsync();
            return Ok(users);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetUserById(int id)
        {
            var user = await _repository.GetUserByIdAsync(id);
            if (user == null)
                return NotFound("User not found.");
            return Ok(user);
        }

        [HttpPut("{id}/block")]
        public async Task<IActionResult> BlockUnblockUser(int id)
        {
            var result = await _repository.ToggleBlockUserAsync(id);
            if (result == null)
                return NotFound("User not found.");
            return Ok(new { message = result });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var result = await _repository.SoftDeleteUserAsync(id);
            if (result == null)
                return NotFound("User not found.");
            return Ok(new { message = result });
        }
    }
}
