﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/admin/bookings")]
    [Authorize(Roles = "Admin")]
    public class AdminBookingController : ControllerBase
    {
        private readonly IAdminBookingRepository _adminBookingRepo;

        public AdminBookingController(IAdminBookingRepository adminBookingRepo)
        {
            _adminBookingRepo = adminBookingRepo;
        }

        // GET: api/admin/bookings
        [HttpGet]
        public async Task<IActionResult> GetAllBookings()
        {
            var bookings = await _adminBookingRepo.GetAllBookingsAsync();
            return Ok(bookings);
        }

        // PUT: api/admin/bookings/{id}/approve
        [HttpPut("{id}/approve")]
        public async Task<IActionResult> ApproveBooking(int id)
        {
            var booking = await _adminBookingRepo.GetBookingByIdAsync(id);
            if (booking == null)
                return NotFound("Booking not found.");

            booking.Status = "Approved";
            await _adminBookingRepo.SaveChangesAsync();

            return Ok(new { message = "Booking approved successfully." });
        }

        // PUT: api/admin/bookings/{id}/reject
        [HttpPut("{id}/reject")]
        public async Task<IActionResult> RejectBooking(int id)
        {
            var booking = await _adminBookingRepo.GetBookingByIdAsync(id);
            if (booking == null)
                return NotFound("Booking not found.");

            booking.Status = "Rejected";
            await _adminBookingRepo.SaveChangesAsync();

            return Ok(new { message = "Booking rejected successfully." });
        }
    }
}
