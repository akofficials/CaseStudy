﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs;
using RentaGo.DTOs.Payment;
using RentaGo.Models;
using System.Security.Claims;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/user/payments")]
    [Authorize(Roles = "User")]
    public class UserPaymentController : ControllerBase
    {
        private readonly RentaGoDbContext _context;

        public UserPaymentController(RentaGoDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> SubmitPayment(PaymentRequest request)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.Name)?.Value!);

            var booking = await _context.Bookings
                .Include(b => b.Car)
                .FirstOrDefaultAsync(b => b.Id == request.BookingId && b.UserId == userId);

            if (booking == null)
                return NotFound("Booking not found.");

            if (booking.Status != "Pending Payment")
                return BadRequest("Payment already processed or not allowed.");

            string? formattedCardNumber = null;

            switch (request.PaymentMethod)
            {
                case "UPI":
                    if (string.IsNullOrWhiteSpace(request.UpiId))
                        return BadRequest("UPI ID is required.");
                    break;

                case "Card":
                    if (string.IsNullOrWhiteSpace(request.CardNumber) ||
                        string.IsNullOrWhiteSpace(request.ExpiryDate) ||
                        string.IsNullOrWhiteSpace(request.CVV))
                        return BadRequest("CardNumber, ExpiryDate and CVV are required.");

                    if (request.CardNumber.Length != 16 || !request.CardNumber.All(char.IsDigit))
                        return BadRequest("Card number must be 16 digits.");

                    formattedCardNumber = string.Join("-", Enumerable.Range(0, 4)
                        .Select(i => request.CardNumber.Substring(i * 4, 4)));

                    if (!System.Text.RegularExpressions.Regex.IsMatch(request.ExpiryDate, @"^(0[1-9]|1[0-2])/20[2-9][0-9]$"))
                        return BadRequest("Expiry date must be in MM/YYYY format and a valid future date.");

                    if (request.CVV.Length != 3 || !request.CVV.All(char.IsDigit))
                        return BadRequest("CVV must be 3 digits.");
                    break;

                case "PayPal":
                    if (string.IsNullOrWhiteSpace(request.PayPalEmail))
                        return BadRequest("PayPal email is required.");
                    break;

                default:
                    return BadRequest("Invalid payment method.");
            }

            var payment = new Payment
            {
                BookingId = request.BookingId,
                PaymentMethod = request.PaymentMethod,
                UpiId = request.PaymentMethod == "UPI" ? request.UpiId : null,
                CardNumber = request.PaymentMethod == "Card" ? formattedCardNumber : null,
                ExpiryDate = request.PaymentMethod == "Card" ? request.ExpiryDate : null,
                CVV = request.PaymentMethod == "Card" ? request.CVV : null,
                PayPalEmail = request.PaymentMethod == "PayPal" ? request.PayPalEmail : null,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Payment submitted. Awaiting admin approval." });
        }

        [HttpGet]
        public async Task<IActionResult> GetMyPayments()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.Name)?.Value!);

            var payments = await _context.Payments
                .Include(p => p.Booking).ThenInclude(b => b.Car)
                .Where(p => p.Booking.UserId == userId)
                .Select(p => new UserPaymentHistoryDto
                {
                    PaymentId = p.Id,
                    BookingId = p.BookingId,
                    Car = p.Booking.Car.Brand + " " + p.Booking.Car.Model,
                    Amount = p.Booking.TotalCost,
                    Status = p.Status,
                    Method = p.PaymentMethod
                })
                .ToListAsync();

            return Ok(payments);
        }
    }
}
