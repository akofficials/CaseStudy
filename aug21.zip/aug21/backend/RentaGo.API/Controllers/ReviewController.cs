﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.Models;
using RentaGo.Models.DTOs;
using RentaGo.Repositories.Interfaces;
using System.Security.Claims;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReviewController : ControllerBase
    {
        private readonly IReviewRepository _reviewRepo;

        public ReviewController(IReviewRepository reviewRepo)
        {
            _reviewRepo = reviewRepo;
        }

        [HttpPost]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> AddReview([FromBody] ReviewRequest request)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.Name));

            var review = new Review
            {
                CarId = request.CarId,
                UserId = userId,
                Rating = request.Rating,
                Comment = request.Comment,
                CreatedAt = DateTime.UtcNow
            };

            await _reviewRepo.AddReviewAsync(review);
            return Ok(new { message = "Review submitted successfully." });
        }

        [HttpGet("car/{carId}")]
        public async Task<IActionResult> GetReviewsByCar(int carId)
        {
            var reviews = await _reviewRepo.GetReviewsByCarAsync(carId);
            return Ok(reviews);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteReview(int id)
        {
            var review = await _reviewRepo.GetReviewByIdAsync(id);
            if (review == null)
                return NotFound(new { message = "Review not found." });

            await _reviewRepo.DeleteReviewAsync(review);
            return Ok(new { message = "Review deleted successfully." });
        }
    }
}
