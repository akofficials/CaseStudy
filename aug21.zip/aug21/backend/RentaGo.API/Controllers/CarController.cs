﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.DTOs.Car;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private readonly ICarRepository _carRepository;

        public CarController(ICarRepository carRepository)
        {
            _carRepository = carRepository;
        }

        // GET: api/car
        // GET: api/car
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CarReadDto>>> GetCars([FromQuery] string? type, [FromQuery] int? seats)
        {
            var cars = await _carRepository.GetFilteredCarsAsync(type, seats);
            return Ok(cars);
        }


        // GET: api/car/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<CarReadDto>> GetCar(int id)
        {
            var car = await _carRepository.GetCarByIdAsync(id);
            if (car == null)
                return NotFound("Car not found.");

            return Ok(car);
        }

        // POST: api/car
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<ActionResult> CreateCar(CarCreateDto request)
        {
            var result = await _carRepository.CreateCarAsync(request);
            return Ok(result);
        }

        // PUT: api/car/{id}
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateCar(int id, CarUpdateDto request)
        {
            var result = await _carRepository.UpdateCarAsync(id, request);
            if (result == "Car not found.")
                return NotFound(result);

            return Ok(result);
        }

        // DELETE: api/car/{id}
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteCar(int id)
        {
            var result = await _carRepository.DeleteCarAsync(id);
            if (result == "Car not found.")
                return NotFound(result);

            return Ok(result);
        }
    }
}
