﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentaGo.Repositories.Interfaces;
using RentaGo.Services;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/admin/payments")]
    [Authorize(Roles = "Admin")]
    public class AdminPaymentController : ControllerBase
    {
        private readonly IAdminPaymentRepository _repository;
        private readonly IEmailService _emailService;

        public AdminPaymentController(IAdminPaymentRepository repository, IEmailService emailService)
        {
            _repository = repository;
            _emailService = emailService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPayments()
        {
            var result = await _repository.GetAllPaymentsAsync();
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPaymentById(int id)
        {
            var result = await _repository.GetPaymentByIdAsync(id);
            return result == null ? NotFound("Payment not found.") : Ok(result);
        }

        [HttpPut("{id}/approve")]
        public async Task<IActionResult> ApprovePayment(int id)
        {
            var (success, payment, msg) = await _repository.ApprovePaymentAsync(id);

            if (!success || payment == null)
                return NotFound(msg);

            // Send email
            var userEmail = payment.Booking.User.Email;
            var car = payment.Booking.Car;
            var subject = "Payment Approved - RentaGo Booking Confirmed";
            var message = $@"
    <div style='font-family:Arial, sans-serif; color:#333; max-width:600px; margin:auto; padding:20px; border:1px solid #ddd; border-radius:8px;'>
        <h2 style='color:#d32f2f;'>RentaGo - Booking Confirmed</h2>
        <p>Dear <strong>{payment.Booking.User.FirstName}</strong>,</p>
        <p>Your payment for the booking of <strong>{car.Brand} {car.Model}</strong> has been 
        <span style='color:green; font-weight:bold;'>approved</span>.</p>
        
        <div style='background:#f9f9f9; padding:15px; border-radius:6px; margin:20px 0;'>
            <p><strong>Booking ID:</strong> {payment.Booking.Id}</p>
            <p><strong>Payment ID:</strong> {payment.Id}</p>
            <p><strong>Pickup Date:</strong> {payment.Booking.PickupDate:dd MMM yyyy HH:mm}</p>
            <p><strong>Dropoff Date:</strong> {payment.Booking.DropoffDate:dd MMM yyyy HH:mm}</p>
            <p><strong>Total Amount:</strong> ₹{payment.Booking.TotalCost}</p>
            <p><Strong>Pick your car at - No.8, abc street, adyar, Chennai-600011 at {payment.Booking.PickupDate:dd MMM yyyy} 08:00 AM</strong></p>
        </div>

        <p style='font-size:15px;'>Your booking is now <strong>confirmed</strong>. 🚗<br/>
        Thank you for choosing <strong style='color:#d32f2f;'>RentaGo</strong>!</p>
        
        <br/>
        <p style='font-size:12px; color:#888;'>If you have any questions, simply reply to this email.</p>
    </div>";


            await _emailService.SendEmailAsync(userEmail, subject, message);

            return Ok(new { message = "Payment approved, booking confirmed, and email sent." });
        }

        [HttpPut("{id}/reject")]
        public async Task<IActionResult> RejectPayment(int id)
        {
            var (success, msg) = await _repository.RejectPaymentAsync(id);
            return success ? Ok(new { message = msg }) : NotFound(msg);
        }
    }
}
