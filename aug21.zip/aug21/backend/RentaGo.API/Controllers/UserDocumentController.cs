﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs;
using RentaGo.Models;
using System.Security.Claims;

namespace RentaGo.Controllers
{
    [ApiController]
    [Route("api/user/documents")]
    [Authorize(Roles = "User")]
    public class UserDocumentController : ControllerBase
    {
        private readonly RentaGoDbContext _context;

        public UserDocumentController(RentaGoDbContext context)
        {
            _context = context;
        }

        // GET: api/user/documents
        [HttpGet]
        public async Task<IActionResult> GetDocument()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.Name)!.Value);
            var document = await _context.Documents
                .Where(d => d.UserId == userId)
                .Select(d => new DocumentDto
                {
                    Id = d.Id,
                    UserId = d.UserId,
                    IsApproved = d.IsApproved,
                    Status = d.Status
                })
                .FirstOrDefaultAsync();

            if (document == null)
                return NotFound("No document uploaded.");

            return Ok(document);
        }

        // POST: api/user/documents
        [HttpPost]
        public async Task<IActionResult> UploadDocument([FromForm] DocumentUploadDto dto)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.Name)!.Value);

            var existing = await _context.Documents.FirstOrDefaultAsync(d => d.UserId == userId);
            if (existing != null)
                return BadRequest("Document already uploaded.");

            var document = new Document
            {
                UserId = userId,
                AadharImage = await GetBytes(dto.AadharImage),
                LicenseImage = await GetBytes(dto.LicenseImage),
                InsuranceImage = await GetBytes(dto.InsuranceImage),
                Status = "Pending",
                IsApproved = false
            };

            _context.Documents.Add(document);
            await _context.SaveChangesAsync();

            return Ok("Documents uploaded.");
        }

        private async Task<byte[]?> GetBytes(IFormFile? file)
        {
            if (file == null || file.Length == 0) return null;

            using var ms = new MemoryStream();
            await file.CopyToAsync(ms);
            return ms.ToArray();
        }
    }
}
