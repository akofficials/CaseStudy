﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RentaGo.API.Migrations
{
    /// <inheritdoc />
    public partial class AddPaymentDetailsFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Cvv",
                table: "Payments",
                newName: "CVV");

            migrationBuilder.RenameColumn(
                name: "Expiry",
                table: "Payments",
                newName: "ExpiryDate");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "CVV",
                table: "Payments",
                newName: "Cvv");

            migrationBuilder.RenameColumn(
                name: "ExpiryDate",
                table: "Payments",
                newName: "Expiry");
        }
    }
}
