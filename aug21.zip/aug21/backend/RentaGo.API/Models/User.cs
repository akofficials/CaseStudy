﻿using System.ComponentModel.DataAnnotations;

namespace RentaGo.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required]
        public string PasswordHash { get; set; }

        [Required]
        public string PhoneNumber { get; set; }

        public string Role { get; set; } = "User";

        public bool IsDeleted { get; set; } = false;

        public bool IsBlocked { get; set; } = false;

        public ICollection<Booking> Bookings { get; set; }
        public ICollection<Review> Reviews { get; set; }
    }
}
