﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RentaGo.Models
{
    public class Payment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int BookingId { get; set; }

        [ForeignKey("BookingId")]
        public Booking Booking { get; set; }

        [Required]
        [Column("Amount")]
        public decimal TotalCost { get; set; }


        [Required]
        public string PaymentMethod { get; set; } // "UPI", "Card", "PayPal"

        public string? UpiId { get; set; }

        public string? CardNumber { get; set; }

        public string? CardHolderName { get; set; }

        public string? ExpiryDate { get; set; }

        public string? CVV { get; set; }

        public string? PayPalEmail { get; set; }

        public string Status { get; set; } = "Pending"; // Pending, Approved, Rejected

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
