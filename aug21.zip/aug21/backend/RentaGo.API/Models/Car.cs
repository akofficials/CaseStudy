﻿using System.ComponentModel.DataAnnotations;

namespace RentaGo.Models
{
    public class Car
    {
        public int Id { get; set; }

        [Required]
        public string Brand { get; set; }

        [Required]
        public string Model { get; set; }

        [Required]
        public string Type { get; set; }  // EV / Diesel / Petrol

        [Required]
        public int Seats { get; set; }    // 5 or 7
        public string Description { get; set; }

        [Required]
        public decimal PricePerDay { get; set; }

        public bool IsAvailable { get; set; } = true;

        public string ImageUrl { get; set; }
        public bool IsDeleted { get; set; } = false;

        public ICollection<Booking> Bookings { get; set; }
        public ICollection<Review> Reviews { get; set; }
    }
}
