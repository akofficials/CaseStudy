﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories.Implementations
{
    public class AdminBookingRepository : IAdminBookingRepository
    {
        private readonly RentaGoDbContext _context;

        public AdminBookingRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<List<AdminBookingResponse>> GetAllBookingsAsync()
        {
            return await _context.Bookings
                .Include(b => b.Car)
                .Include(b => b.User)
                .Select(b => new AdminBookingResponse
                {
                    Id = b.Id,
                    PickupDate = b.PickupDate,
                    DropoffDate = b.DropoffDate,
                    TotalCost = b.TotalCost,
                    Status = b.Status,
                    Car = new AdminBookingResponse.CarInfo
                    {
                        Id = b.Car.Id,
                        Brand = b.Car.Brand,
                        Model = b.Car.Model,
                        ImageUrl = b.Car.ImageUrl
                    },
                    User = new AdminBookingResponse.UserInfo
                    {
                        Id = b.User.Id,
                        FullName = $"{b.User.FirstName} {b.User.LastName}",
                        Email = b.User.Email,
                        PhoneNumber = b.User.PhoneNumber
                    }
                }).ToListAsync();
        }

        public async Task<Booking?> GetBookingByIdAsync(int id)
        {
            return await _context.Bookings.FindAsync(id);
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
