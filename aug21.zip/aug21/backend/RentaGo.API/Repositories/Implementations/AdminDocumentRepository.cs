﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories.Implementations
{
    public class AdminDocumentRepository : IAdminDocumentRepository
    {
        private readonly RentaGoDbContext _context;

        public AdminDocumentRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<DocumentPreviewDto>> GetAllDocumentsAsync()
        {
            var documents = await _context.Documents.Include(d => d.User).ToListAsync();

            return documents.Select(doc => new DocumentPreviewDto
            {
                Id = doc.Id,
                UserId = doc.UserId,
                Status = doc.Status,
                IsApproved = doc.IsApproved,
                AadharUrl = doc.AadharImage != null ? $"aadhar" : null,
                LicenseUrl = doc.LicenseImage != null ? $"license" : null,
                InsuranceUrl = doc.InsuranceImage != null ? $"insurance" : null
            });
        }

        public async Task<Document?> GetDocumentByIdAsync(int id)
        {
            return await _context.Documents.Include(d => d.User).FirstOrDefaultAsync(d => d.Id == id);
        }

        public async Task<IEnumerable<Document>> GetDocumentsByStatusAsync(string status)
        {
            return await _context.Documents
                .Include(d => d.User)
                .Where(d => d.Status.ToLower() == status.ToLower())
                .ToListAsync();
        }

        public async Task<byte[]?> GetImageAsync(int id, string type)
        {
            var doc = await _context.Documents.FindAsync(id);
            if (doc == null) return null;

            return type.ToLower() switch
            {
                "aadhar" => doc.AadharImage,
                "license" => doc.LicenseImage,
                "insurance" => doc.InsuranceImage,
                _ => null
            };
        }

        public async Task<bool> ApproveDocumentAsync(int id)
        {
            var doc = await _context.Documents.FindAsync(id);
            if (doc == null) return false;

            doc.IsApproved = true;
            doc.Status = "Approved";
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RejectDocumentAsync(int id)
        {
            var doc = await _context.Documents.FindAsync(id);
            if (doc == null) return false;

            doc.IsApproved = false;
            doc.Status = "Rejected";
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
