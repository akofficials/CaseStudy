﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories.Implementations
{
    public class AdminReviewRepository : IAdminReviewRepository
    {
        private readonly RentaGoDbContext _context;

        public AdminReviewRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Review>> GetAllReviewsAsync()
        {
            return await _context.Reviews
                .Include(r => r.Car)
                .Include(r => r.User)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
        }
    }
}
