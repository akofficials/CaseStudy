﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories.Implementations
{
    public class AdminUserRepository : IAdminUserRepository
    {
        private readonly RentaGoDbContext _context;

        public AdminUserRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            return await _context.Users
                .Where(u => u.Role == "User")
                .ToListAsync();
        }

        public async Task<User?> GetUserByIdAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);
            return user != null && user.Role == "User" ? user : null;
        }

        public async Task<string?> ToggleBlockUserAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null || user.Role != "User") return null;

            user.IsBlocked = !user.IsBlocked;
            await _context.SaveChangesAsync();

            return user.IsBlocked ? "User blocked." : "User unblocked.";
        }

        public async Task<string?> SoftDeleteUserAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null || user.Role != "User") return null;

            user.IsDeleted = true;
            await _context.SaveChangesAsync();

            return "User deleted (soft delete).";
        }
    }
}
