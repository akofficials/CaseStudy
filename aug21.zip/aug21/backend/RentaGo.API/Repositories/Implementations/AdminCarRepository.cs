﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs.Car;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories.Implementations
{
    public class AdminCarRepository : IAdminCarRepository
    {
        private readonly RentaGoDbContext _context;

        public AdminCarRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<List<Car>> GetAllCarsAsync()
        {
            return await _context.Cars
                .Where(c => !c.IsDeleted)
                .ToListAsync();
        }

        public async Task<Car?> GetCarByIdAsync(int id)
        {
            var car = await _context.Cars.FindAsync(id);
            return (car == null || car.IsDeleted) ? null : car;
        }

        public async Task<Car> AddCarAsync(AddCarRequest request)
        {
            var car = new Car
            {
                Brand = request.Brand,
                Model = request.Model,
                Type = request.Type,
                Seats = request.Seats,
                Description = request.Description,
                PricePerDay = request.PricePerDay,
                ImageUrl = request.ImageUrl,
                IsAvailable = true,
                IsDeleted = false
            };

            _context.Cars.Add(car);
            await _context.SaveChangesAsync();
            return car;
        }

        public async Task<bool> UpdateCarAsync(int id, UpdateCarRequest request)
        {
            var car = await _context.Cars.FindAsync(id);
            if (car == null || car.IsDeleted)
                return false;

            car.Brand = request.Brand;
            car.Model = request.Model;
            car.Description = request.Description;
            car.Type = request.Type;
            car.Seats = request.Seats;
            car.PricePerDay = request.PricePerDay;
            car.ImageUrl = request.ImageUrl;
            car.IsAvailable = request.IsAvailable;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> SoftDeleteCarAsync(int id)
        {
            var car = await _context.Cars.FindAsync(id);
            if (car == null || car.IsDeleted)
                return false;

            car.IsDeleted = true;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
