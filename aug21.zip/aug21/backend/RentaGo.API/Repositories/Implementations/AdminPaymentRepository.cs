﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs.Payment;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories.Implementations
{
    public class AdminPaymentRepository : IAdminPaymentRepository
    {
        private readonly RentaGoDbContext _context;

        public AdminPaymentRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<AdminPaymentResponse>> GetAllPaymentsAsync()
        {
            return await _context.Payments
                .Include(p => p.Booking).ThenInclude(b => b.Car)
                .Include(p => p.Booking).ThenInclude(b => b.User)
                .Select(p => new AdminPaymentResponse
                {
                    Id = p.Id,
                    BookingId = p.BookingId,
                    PaymentMethod = p.PaymentMethod,
                    UpiId = p.UpiId,
                    CardNumber = p.CardNumber,
                    PayPalEmail = p.PayPalEmail,
                    Amount = p.Booking.TotalCost,
                    Status = p.Status,
                    Car = p.Booking.Car.Brand + " " + p.Booking.Car.Model,
                    UserEmail = p.Booking.User.Email
                })
                .ToListAsync();
        }

        public async Task<AdminPaymentResponse?> GetPaymentByIdAsync(int id)
        {
            return await _context.Payments
                .Include(p => p.Booking).ThenInclude(b => b.Car)
                .Include(p => p.Booking).ThenInclude(b => b.User)
                .Where(p => p.Id == id)
                .Select(p => new AdminPaymentResponse
                {
                    Id = p.Id,
                    BookingId = p.BookingId,
                    PaymentMethod = p.PaymentMethod,
                    UpiId = p.UpiId,
                    CardNumber = p.CardNumber,
                    PayPalEmail = p.PayPalEmail,
                    Amount = p.Booking.TotalCost,
                    Status = p.Status,
                    Car = p.Booking.Car.Brand + " " + p.Booking.Car.Model,
                    UserEmail = p.Booking.User.Email
                })
                .FirstOrDefaultAsync();
        }

        public async Task<(bool, Payment?, string)> ApprovePaymentAsync(int id)
        {
            var payment = await _context.Payments
                .Include(p => p.Booking).ThenInclude(b => b.User)
                .Include(p => p.Booking.Car)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (payment == null)
                return (false, null, "Payment not found.");

            payment.Status = "Approved";
            payment.Booking.Status = "Confirmed";
            await _context.SaveChangesAsync();

            return (true, payment, "Payment approved and booking confirmed.");
        }

        public async Task<(bool, string)> RejectPaymentAsync(int id)
        {
            var payment = await _context.Payments
                .Include(p => p.Booking)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (payment == null)
                return (false, "Payment not found.");

            payment.Status = "Rejected";
            payment.Booking.Status = "Rejected";
            await _context.SaveChangesAsync();

            return (true, "Payment rejected and booking marked as rejected.");
        }
    }
}
