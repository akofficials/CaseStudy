﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories.Implementations
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly RentaGoDbContext _context;

        public ReviewRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task AddReviewAsync(Review review)
        {
            _context.Reviews.Add(review);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<object>> GetReviewsByCarAsync(int carId)
        {
            return await _context.Reviews
                .Include(r => r.User)
                .Where(r => r.CarId == carId)
                .Select(r => new
                {
                    r.Id,
                    r.Rating,
                    r.Comment,
                    r.CreatedAt,
                    Reviewer = $"{r.User.FirstName} {r.User.LastName}"
                })
                .ToListAsync();
        }

        public async Task<Review?> GetReviewByIdAsync(int id)
        {
            return await _context.Reviews.FindAsync(id);
        }

        public async Task DeleteReviewAsync(Review review)
        {
            _context.Reviews.Remove(review);
            await _context.SaveChangesAsync();
        }
    }
}
