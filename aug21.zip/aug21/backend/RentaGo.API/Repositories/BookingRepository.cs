﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories
{
    public class BookingRepository : IBookingRepository
    {
        private readonly RentaGoDbContext _context;

        public BookingRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<(bool success, string message, int bookingId, decimal amount)> CreateBookingAsync(BookingRequest request, int userId)
        {
            var document = await _context.Documents.FirstOrDefaultAsync(d => d.UserId == userId);
            if (document == null || !document.IsApproved || !HasAtLeastTwoDocuments(document))
                return (false, "You must upload at least 2 documents and get approval before booking.", 0, 0);

            var car = await _context.Cars.FindAsync(request.CarId);
            if (car == null)
                return (false, "Car not found.", 0, 0);
            if (!car.IsAvailable)
                return (false, $"Car is temporarily unavailable for booking.", 0, 0);

            // Find an overlapping booking (not cancelled)
            var overlappingBooking = await _context.Bookings
                .Where(b =>
                    b.CarId == request.CarId &&
                    b.Status != "Cancelled" &&
                    b.PickupDate < request.DropoffDate &&
                    request.PickupDate < b.DropoffDate)
                .OrderBy(b => b.PickupDate)
                .FirstOrDefaultAsync();

            if (overlappingBooking != null)
            {
                return (false,
                    $"Car is not available from {overlappingBooking.PickupDate:yyyy-MM-dd} to {overlappingBooking.DropoffDate:yyyy-MM-dd}",
                    0, 0);
            }

            var days = (request.DropoffDate - request.PickupDate).Days;
            if (days <= 0)
                return (false, "Invalid booking dates.", 0, 0);

            var totalCost = days * car.PricePerDay;

            var booking = new Booking
            {
                CarId = request.CarId,
                UserId = userId,
                PickupDate = request.PickupDate,
                DropoffDate = request.DropoffDate,
                TotalCost = totalCost,
                Status = "Pending Payment"
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            return (true, "Booking created. Awaiting payment.", booking.Id, totalCost);
        }


        public async Task<IEnumerable<BookingResponse>> GetUserBookingsAsync(int userId)
        {
            return await _context.Bookings
                .Include(b => b.Car)
                .Include(b => b.User)
                .Where(b => b.UserId == userId)
                .Select(b => new BookingResponse
                {
                    Id = b.Id,
                    CarModel = b.Car.Model,
                    Brand = b.Car.Brand,
                    UserEmail = b.User.Email,
                    PickupDate = b.PickupDate,
                    DropoffDate = b.DropoffDate,
                    TotalCost = b.TotalCost,
                    Status = b.Status
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<BookingResponse>> GetAllBookingsAsync()
        {
            return await _context.Bookings
                .Include(b => b.Car)
                .Include(b => b.User)
                .Select(b => new BookingResponse
                {
                    Id = b.Id,
                    CarModel = b.Car.Model,
                    Brand = b.Car.Brand,
                    UserEmail = b.User.Email,
                    PickupDate = b.PickupDate,
                    DropoffDate = b.DropoffDate,
                    TotalCost = b.TotalCost,
                    Status = b.Status
                })
                .ToListAsync();
        }

        public async Task<bool> CancelBookingAsync(int bookingId, int userId, string role)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking == null || booking.Status == "Cancelled")
                return false;

            if (role != "Admin" && booking.UserId != userId)
                return false;

            booking.Status = "Cancelled";
            await _context.SaveChangesAsync();
            return true;
        }

        private bool HasAtLeastTwoDocuments(Document doc)
        {
            int count = 0;
            if (doc.AadharImage != null) count++;
            if (doc.LicenseImage != null) count++;
            if (doc.InsuranceImage != null) count++;
            return count >= 2;
        }
    }
}
