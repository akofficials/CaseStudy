﻿namespace RentaGo.API.Repositories
{
    public class ReviewRepository
    {
    }
}
