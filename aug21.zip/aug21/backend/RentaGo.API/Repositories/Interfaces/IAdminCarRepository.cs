﻿using RentaGo.DTOs.Car;
using RentaGo.Models;

namespace RentaGo.Repositories.Interfaces
{
    public interface IAdminCarRepository
    {
        Task<List<Car>> GetAllCarsAsync();
        Task<Car?> GetCarByIdAsync(int id);
        Task<Car> AddCarAsync(AddCarRequest request);
        Task<bool> UpdateCarAsync(int id, UpdateCarRequest request);
        Task<bool> SoftDeleteCarAsync(int id);
    }
}
