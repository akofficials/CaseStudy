﻿using RentaGo.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RentaGo.Repositories.Interfaces
{
    public interface IReviewRepository
    {
        Task AddReviewAsync(Review review);
        Task<IEnumerable<object>> GetReviewsByCarAsync(int carId);
        Task<Review?> GetReviewByIdAsync(int id);
        Task DeleteReviewAsync(Review review);
    }
}
