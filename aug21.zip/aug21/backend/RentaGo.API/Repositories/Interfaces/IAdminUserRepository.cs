﻿using RentaGo.Models;

namespace RentaGo.Repositories.Interfaces
{
    public interface IAdminUserRepository
    {
        Task<IEnumerable<User>> GetAllUsersAsync();
        Task<User?> GetUserByIdAsync(int id);
        Task<string?> ToggleBlockUserAsync(int id);
        Task<string?> SoftDeleteUserAsync(int id);
    }
}
