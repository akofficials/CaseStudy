﻿using RentaGo.DTOs;
using RentaGo.Models;

namespace RentaGo.Repositories.Interfaces
{
    public interface IAdminDocumentRepository
    {
        Task<IEnumerable<DocumentPreviewDto>> GetAllDocumentsAsync();
        Task<Document?> GetDocumentByIdAsync(int id);
        Task<IEnumerable<Document>> GetDocumentsByStatusAsync(string status);
        Task<byte[]?> GetImageAsync(int id, string type);
        Task<bool> ApproveDocumentAsync(int id);
        Task<bool> RejectDocumentAsync(int id);
    }
}
