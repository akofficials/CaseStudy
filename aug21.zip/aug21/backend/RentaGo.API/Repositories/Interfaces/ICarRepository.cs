﻿using RentaGo.DTOs.Car;

namespace RentaGo.Repositories.Interfaces
{
    public interface ICarRepository
    {
        Task<IEnumerable<CarReadDto>> GetFilteredCarsAsync(string? type, int? seats);
        Task<CarReadDto?> GetCarByIdAsync(int id);
        Task<string> CreateCarAsync(CarCreateDto request);
        Task<string> UpdateCarAsync(int id, CarUpdateDto request);
        Task<string> DeleteCarAsync(int id);
    }
}
