﻿using RentaGo.DTOs;
using RentaGo.Models.DTOs;

namespace RentaGo.Repositories.Interfaces
{
    public interface IAuthRepository
    {
        Task<string?> RegisterAsync(RegisterRequest request);
        Task<(string? Token, string? Email, string? Role, string? Error)> LoginAsync(LoginRequest request);
    }
}
