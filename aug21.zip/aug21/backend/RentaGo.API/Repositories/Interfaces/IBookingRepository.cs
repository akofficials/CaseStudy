﻿using RentaGo.DTOs;
using RentaGo.Models;

namespace RentaGo.Repositories.Interfaces
{
    public interface IBookingRepository
    {
        Task<(bool success, string message, int bookingId, decimal amount)> CreateBookingAsync(BookingRequest request, int userId);
        Task<IEnumerable<BookingResponse>> GetUserBookingsAsync(int userId);
        Task<IEnumerable<BookingResponse>> GetAllBookingsAsync();
        Task<bool> CancelBookingAsync(int bookingId, int userId, string role);
    }
}
