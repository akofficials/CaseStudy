﻿using RentaGo.DTOs.User;

namespace RentaGo.Repositories.Interfaces
{
    public interface IUserRepository
    {
        Task<UserProfileDto?> GetUserProfileAsync(int userId);
        Task<string> UpdateUserProfileAsync(int userId, UserProfileUpdateDto updateDto);
    }
}
