﻿using RentaGo.Models;

namespace RentaGo.Repositories.Interfaces
{
    public interface IAdminReviewRepository
    {
        Task<IEnumerable<Review>> GetAllReviewsAsync();
    }
}
