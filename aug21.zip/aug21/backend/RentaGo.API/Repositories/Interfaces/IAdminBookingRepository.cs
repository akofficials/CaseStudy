﻿using RentaGo.DTOs;
using RentaGo.Models;

namespace RentaGo.Repositories.Interfaces
{
    public interface IAdminBookingRepository
    {
        Task<List<AdminBookingResponse>> GetAllBookingsAsync();
        Task<Booking?> GetBookingByIdAsync(int id);
        Task SaveChangesAsync();
    }
}
