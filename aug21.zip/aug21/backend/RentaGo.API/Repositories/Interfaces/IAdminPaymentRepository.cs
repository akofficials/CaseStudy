﻿using RentaGo.DTOs.Payment;
using RentaGo.Models;

namespace RentaGo.Repositories.Interfaces
{
    public interface IAdminPaymentRepository
    {
        Task<IEnumerable<AdminPaymentResponse>> GetAllPaymentsAsync();
        Task<AdminPaymentResponse?> GetPaymentByIdAsync(int id);
        Task<(bool success, Payment? payment, string message)> ApprovePaymentAsync(int id);
        Task<(bool success, string message)> RejectPaymentAsync(int id);
    }
}
