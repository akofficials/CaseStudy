﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs.Car;
using RentaGo.Models;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories
{
    public class CarRepository : ICarRepository
    {
        private readonly RentaGoDbContext _context;

        public CarRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<CarReadDto>> GetFilteredCarsAsync(string? type, int? seats)
        {
            var query = _context.Cars
                .Where(c => !c.IsDeleted);

            if (!string.IsNullOrEmpty(type))
                query = query.Where(c => c.Type.ToLower() == type.ToLower());

            if (seats.HasValue)
                query = query.Where(c => c.Seats == seats.Value);

            return await query
                .Select(c => new CarReadDto
                {
                    Id = c.Id,
                    Brand = c.Brand,
                    Model = c.Model,
                    Description = c.Description,
                    PricePerDay = c.PricePerDay,
                    ImageUrl = c.ImageUrl,
                    IsAvailable = c.IsAvailable,
                    Type = c.Type,
                    Seats = c.Seats
                })
                .ToListAsync();
        }


        public async Task<CarReadDto?> GetCarByIdAsync(int id)
        {
            var car = await _context.Cars.FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
            if (car == null) return null;

            return new CarReadDto
            {
                Id = car.Id,
                Brand = car.Brand,
                Model = car.Model,
                Type = car.Type,
                Seats = car.Seats,
                Description = car.Description,
                PricePerDay = car.PricePerDay,
                ImageUrl = car.ImageUrl,
                IsAvailable = car.IsAvailable
            };
        }

        public async Task<string> CreateCarAsync(CarCreateDto request)
        {
            var car = new Car
            {
                Brand = request.Brand,
                Model = request.Model,
                Type = request.Type,
                Seats = request.Seats,
                Description = request.Description,
                PricePerDay = request.PricePerDay,
                ImageUrl = request.ImageUrl,
                IsAvailable = true
            };

            _context.Cars.Add(car);
            await _context.SaveChangesAsync();
            return "Car added successfully.";
        }

        public async Task<string> UpdateCarAsync(int id, CarUpdateDto request)
        {
            var car = await _context.Cars.FindAsync(id);
            if (car == null || car.IsDeleted) return "Car not found.";

            car.Brand = request.Brand;
            car.Model = request.Model;
            car.Type = request.Type;
            car.Seats = request.Seats;  
            car.Description = request.Description;
            car.PricePerDay = request.PricePerDay;
            car.ImageUrl = request.ImageUrl;
            car.IsAvailable = request.IsAvailable;

            await _context.SaveChangesAsync();
            return "Car updated successfully.";
        }

        public async Task<string> DeleteCarAsync(int id)
        {
            var car = await _context.Cars.FindAsync(id);
            if (car == null || car.IsDeleted) return "Car not found.";

            car.IsDeleted = true;
            await _context.SaveChangesAsync();
            return "Car deleted (soft delete).";
        }
    }
}
