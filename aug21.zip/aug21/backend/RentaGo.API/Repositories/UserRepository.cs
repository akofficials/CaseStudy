﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Data;
using RentaGo.DTOs.User;
using RentaGo.Repositories.Interfaces;

namespace RentaGo.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly RentaGoDbContext _context;

        public UserRepository(RentaGoDbContext context)
        {
            _context = context;
        }

        public async Task<UserProfileDto?> GetUserProfileAsync(int userId)
        {
            var user = await _context.Users
                .Where(u => u.Id == userId && !u.IsDeleted)
                .Select(u => new UserProfileDto
                {
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    PhoneNumber = u.PhoneNumber
                })
                .FirstOrDefaultAsync();

            return user;
        }

        public async Task<string> UpdateUserProfileAsync(int userId, UserProfileUpdateDto updateDto)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null || user.IsDeleted)
                return "User not found.";

            user.FirstName = updateDto.FirstName;
            user.LastName = updateDto.LastName;
            user.PhoneNumber = updateDto.PhoneNumber;

            await _context.SaveChangesAsync();
            return "Profile updated successfully.";
        }
    }
}
