﻿using Microsoft.EntityFrameworkCore;
using RentaGo.Models;

namespace RentaGo.Data
{
    public class RentaGoDbContext : DbContext
    {
        public RentaGoDbContext(DbContextOptions<RentaGoDbContext> options)
            : base(options)
        {
        }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<Review> Reviews { get; set; }
    }
}
