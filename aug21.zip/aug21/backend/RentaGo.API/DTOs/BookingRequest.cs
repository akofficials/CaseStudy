﻿using System.ComponentModel.DataAnnotations;

namespace RentaGo.DTOs
{
    public class BookingRequest
    {
        [Required]
        public int CarId { get; set; }

        [Required]
        public DateTime PickupDate { get; set; }

        [Required]
        public DateTime DropoffDate { get; set; }
    }
}
