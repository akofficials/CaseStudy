﻿using System.ComponentModel.DataAnnotations;

namespace RentaGo.DTOs.Car
{
    public class CarCreateDto
    {
        [Required]
        public string Brand { get; set; }

        [Required]
        public string Model { get; set; }

        [Required]
        public string Type { get; set; }

        [Required]
        public int Seats { get; set; }

        public string Description { get; set; }

        [Required]
        public decimal PricePerDay { get; set; }

        public string ImageUrl { get; set; }
    }
}
