﻿public class AdminBookingResponse
{
    public int Id { get; set; }
    public DateTime PickupDate { get; set; }
    public DateTime DropoffDate { get; set; }
    public decimal TotalCost { get; set; }
    public string Status { get; set; }

    public CarInfo Car { get; set; }
    public UserInfo User { get; set; }

    public class CarInfo
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string ImageUrl { get; set; }
    }

    public class UserInfo
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
