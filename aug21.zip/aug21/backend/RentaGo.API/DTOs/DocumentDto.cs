﻿namespace RentaGo.DTOs
{
    public class DocumentDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public bool IsApproved { get; set; }
        public string Status { get; set; }
    }
}
