﻿namespace RentaGo.DTOs.Payment
{
    public class AdminPaymentResponse
    {
        public int Id { get; set; }
        public int BookingId { get; set; }
        public string PaymentMethod { get; set; }
        public string? UpiId { get; set; }
        public string? CardNumber { get; set; }
        public string? PayPalEmail { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }

        public string Car { get; set; }
        public string UserEmail { get; set; }
    }
}
