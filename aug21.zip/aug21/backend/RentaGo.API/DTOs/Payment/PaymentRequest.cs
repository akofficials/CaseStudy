﻿namespace RentaGo.DTOs
{
    public class PaymentRequest
    {
        public int BookingId { get; set; }
        public string PaymentMethod { get; set; }  // UPI, Card, PayPal

        // UPI
        public string? UpiId { get; set; }

        // Card
        public string? CardNumber { get; set; }
        public string? ExpiryDate { get; set; }  // Format: MM/YYYY
        public string? CVV { get; set; }

        // PayPal
        public string? PayPalEmail { get; set; }
    }
}
