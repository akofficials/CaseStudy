﻿namespace RentaGo.DTOs
{
    public class DocumentResponseDto
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public string AadharBase64 { get; set; }

        public string LicenseBase64 { get; set; }

        public string InsuranceBase64 { get; set; }

        public bool IsApproved { get; set; }

        public string Status { get; set; }
    }
}
