﻿namespace RentaGo.DTOs.Review
{
    public class ReviewResponse
    {
        public int Id { get; set; }
        public int CarId { get; set; }
        public string CarName { get; set; }
        public int UserId { get; set; }
        public string UserEmail { get; set; }
        public int Rating { get; set; }
        public string Comment { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
