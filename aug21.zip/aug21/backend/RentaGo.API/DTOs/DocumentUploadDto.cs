﻿using Microsoft.AspNetCore.Http;

namespace RentaGo.DTOs
{
    public class DocumentUploadDto
    {
        public int UserId { get; set; }

        public IFormFile AadharImage { get; set; }

        public IFormFile LicenseImage { get; set; }

        public IFormFile InsuranceImage { get; set; }
    }
}
