﻿namespace RentaGo.DTOs
{
    public class BookingResponse
    {
        public int Id { get; set; }
        public string CarModel { get; set; }
        public string Brand { get; set; }
        public string UserEmail { get; set; }
        public DateTime PickupDate { get; set; }
        public DateTime DropoffDate { get; set; }
        public decimal TotalCost { get; set; }
        public string Status { get; set; }
    }
}
