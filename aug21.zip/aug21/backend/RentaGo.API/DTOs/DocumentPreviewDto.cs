﻿namespace RentaGo.DTOs
{
    public class DocumentPreviewDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Status { get; set; }
        public bool IsApproved { get; set; }

        public string? AadharUrl { get; set; }
        public string? LicenseUrl { get; set; }
        public string? InsuranceUrl { get; set; }
    }
}
