﻿namespace RentaGo.DTOs.Booking
{
    public class BookingStatusUpdateRequest
    {
        public string Status { get; set; } // Expected: "Approved", "Rejected", "Cancelled"
    }
}
