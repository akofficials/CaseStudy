﻿namespace RentaGo.DTOs.Car
{
    public class UpdateCarRequest
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Type { get; set; }
        public int Seats { get; set; }
        public string Description { get; set; }
        public decimal PricePerDay { get; set; }
        public string ImageUrl { get; set; }
        public bool IsAvailable { get; set; }
    }
}
